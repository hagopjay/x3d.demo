# SPDX-FileCopyrightText: 2026 HagopJay
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""IR -> X3D 4.0 XML emitter.

Pure Python, no ``bpy``. Nodes are written with DEF on first use and USE on
every later use, so repeated meshes and materials are shared instead of
duplicated.
"""

from __future__ import annotations

import hashlib
import logging
import math
import os
import re
import struct
from dataclasses import dataclass, replace
from itertools import chain
from xml.sax.saxutils import escape, quoteattr

try:
    from .extract import display_colour
    from .interaction import tour_timeline
    from .ir import IRMetadata, IRScene
    from .splat_gltf import splat_glb_bytes
    from .splat_io import sh0_to_rgb
except ImportError:  # pragma: no cover - standalone test fallback
    from extract import display_colour
    from interaction import tour_timeline
    from ir import IRMetadata, IRScene
    from splat_gltf import splat_glb_bytes
    from splat_io import sh0_to_rgb


def _safe_name(name: str, fallback: str = "Node") -> str:
    clean = []
    for index, char in enumerate(name or fallback):
        if char.isalnum() or char == "_":
            clean.append(char)
        else:
            clean.append("_")
        if index == 0 and clean[-1].isdigit():
            clean[-1] = "_"
    return "".join(clean) or fallback


class _DefNames:
    """Allocate unique DEF names per IR object key and track first use."""

    def __init__(self):
        self._by_key: dict[tuple[str, str], str] = {}
        self._used: set[str] = set()
        self.emitted: set[tuple[str, str]] = set()
        self._sidecars: dict[str, str] = {}      # sidecar file name -> sha256 of its bytes

    def get(self, kind: str, key: str, prefix: str, label: str | None = None) -> str:
        """The DEF for ``key`` of ``kind``, made from ``label`` (default ``key``) and unique in the file."""
        lookup = (kind, key)
        name = self._by_key.get(lookup)
        if name is None:
            base = f"{prefix}{_safe_name(label if label is not None else key, kind)}"
            name = base
            counter = 1
            while name in self._used:
                counter += 1
                name = f"{base}_{counter}"
            self._used.add(name)
            self._by_key[lookup] = name
        return name

    def sidecar(self, wanted: str, digest: str) -> str:
        """The file name for sidecar bytes with this ``digest``: ``wanted`` when it is free or already holds the same
        bytes, else ``wanted`` with the digest's first characters before the extension. Two different contents never get
        one name (mesh names ``A B`` and ``A_B`` both sanitise to ``A_B``)."""
        stem, dot, extension = wanted.partition(".")
        name, length = wanted, 8
        while self._sidecars.get(name, digest) != digest:
            name = f"{stem}_{digest[:length]}{dot}{extension}"
            length += 4
        self._sidecars[name] = digest
        return name

    def first_use(self, kind: str, key: str) -> bool:
        lookup = (kind, key)
        if lookup in self.emitted:
            return False
        self.emitted.add(lookup)
        return True


_NONFINITE = {"count": 0}


def _finite(value) -> float:
    """``value`` as a float; NaN and infinity become 0 (X3D has no such literal, and "nan" makes the file invalid).
    The count is read by ``nonfinite_count`` so the exporter can warn that data was replaced."""
    value = float(value)
    if value != value or value in (float("inf"), float("-inf")):
        _NONFINITE["count"] += 1
        return 0.0
    return value


def nonfinite_count() -> int:
    """How many NaN or infinite numbers were written as 0 since the process started."""
    return _NONFINITE["count"]


def _fmt(value: float) -> str:
    return "%.6f" % _finite(value)


def _fmt_short(value: float) -> str:
    """Six decimals with the trailing zeros dropped: the interpolator arrays dominate an animated file's size."""
    text = ("%.6f" % _finite(value)).rstrip("0").rstrip(".")
    return "0" if text in ("", "-0") else text


def _fmt2(values):
    return "%.6f %.6f" % tuple(_finite(v) for v in values[:2])


def _fmt3(values):
    return "%.6f %.6f %.6f" % tuple(_finite(v) for v in values[:3])


def _fmt_length(value: float) -> str:
    """A translation or scale component: six decimals as before, but significant digits below 1e-3, where six
    decimals kept too few digits or printed 0 (a scale of 1.057e-16, one unit = one light-year, became
    "0.000000"; a molecule built in metres lost every atom position)."""
    value = _finite(value)
    if value != 0.0 and abs(value) < 1e-3:
        return "%.9g" % value
    return "%.6f" % value


def _fmt3_length(values):
    return " ".join(_fmt_length(float(value)) for value in values[:3])


def _fmt_points(points):
    """Coordinate points: lengths, so below 1e-3 they keep significant digits (a 3e-7 mesh was written as zeros)."""
    return " ".join(_fmt3_length(point) for point in points)


def _fmt_short_length(value: float) -> str:
    """``_fmt_short`` for a length: trailing zeros dropped, significant digits below 1e-3."""
    value = _finite(value)
    if value != 0.0 and abs(value) < 1e-3:
        return "%.9g" % value
    return _fmt_short(value)


def _sfcolor(values):
    """Fit an RGB triple into the SFColor range [0, 1] that the X3D 4.0 XSD enforces.

    Blender multiplies Emission Color by Emission Strength, so an emissive
    material routinely carries channels above 1. X3D 4.0 has no emissive
    strength field, so channels above 1 are scaled down together, which keeps
    the hue and drops only the intensity. Negative channels clip to 0.
    """
    rgb = [max(0.0, float(channel)) for channel in values[:3]]
    peak = max(rgb)
    if peak > 1.0:
        rgb = [channel / peak for channel in rgb]
    return tuple(rgb)


def _fmt4(values):
    return "%.6f %.6f %.6f %.6f" % tuple(_finite(v) for v in values[:4])


def _unit_rgba(values):
    """An RGBA colour clamped per channel to [0, 1], the SFColorRGBA range the X3D 4.0 XSD enforces. Float colour
    attributes can carry channels just past 1 (molecularnodes' pLDDT palette has a red of 1.000169) or below 0, and the
    validator refuses the whole ColorRGBA for one of them."""
    return tuple(min(1.0, max(0.0, float(channel))) for channel in values[:4])


def _fmt_ints(values):
    return " ".join(str(value) for value in values)


def _mfstring(values):
    """Encode a list of strings as an X3D MFString attribute value (single-quoted)."""
    parts = ['"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"' for value in values]
    return escape(" ".join(parts)).replace("'", "&apos;")


# ---------------------------------------------------------------------------
# Appearance


@dataclass(frozen=True)
class _Look:
    """How the materials of one export are written: ``classic`` is the scene's material model (X3D Materials, Phong, or
    PhysicalMaterials), ``forced`` that the export option chose it (every material then follows it; otherwise a
    material the import made from a Material keeps being one), ``colour_space`` what the classic colours are encoded
    for ('SRGB' or 'AS_IS')."""

    classic: bool = False
    colour_space: str = "AS_IS"
    forced: bool = False


_PLAIN_LOOK = _Look()
# Metallic above this has no Phong counterpart (a Material has no metal reflection): such a material stays a PhysicalMaterial.
_CLASSIC_MAX_METALLIC = 0.1


def _is_classic(material, look: _Look) -> bool:
    """True when ``material`` is written as an X3D Material: it is lit (not an UnlitMaterial), expressible as Phong (not
    metallic, no metallic-roughness texture), and either the export option chose the classic model or, left to the
    scene, the material was imported from a Material or the scene's model is classic."""
    if material is None or material.unlit:
        return False
    if material.metallic is not None and material.metallic > _CLASSIC_MAX_METALLIC:
        return False
    if material.metallic_roughness_texture is not None:
        return False
    if look.forced:
        return look.classic
    return look.classic or material.model == "classic"


def phong_from_principled(roughness, specular_level, specular_tint):
    """(shininess, linear specularColor) of X3D's Blinn-Phong for a Principled BSDF's roughness, Specular IOR Level and
    Specular Tint: the inverse of import_x3d.phong_to_principled. A Blinn-Phong exponent n = 128 x shininess matches
    a GGX alpha of sqrt(2 / (n + 2)), and Blender's roughness is sqrt(alpha), so n = 2 / roughness^4 - 2; the peak
    (largest specularColor channel) is F0 (n + 2) / 8, F0 = 0.08 x level the reflectance at normal incidence. A level
    the import capped at 1 (a bright specularColor on a broad lobe) comes back as the largest peak that level can
    carry, since the capped value is all Blender holds."""
    roughness = 0.5 if roughness is None else max(0.05, min(1.0, float(roughness)))
    n = max(0.0, 2.0 / roughness ** 4 - 2.0)
    shininess = max(0.0, min(1.0, n / 128.0))
    level = 0.5 if specular_level is None else max(0.0, min(1.0, float(specular_level)))
    peak = min(1.0, 0.08 * level * (n + 2.0) / 8.0)
    tint = tuple(max(0.0, min(1.0, float(c))) for c in (specular_tint or (1.0, 1.0, 1.0))[:3])
    return shininess, tuple(peak * c for c in tint)


def _texture_url(texture_ref, output_dir=None):
    url = texture_ref.url
    if url is None:
        url = texture_ref.filepath or texture_ref.image_name or ""
        if url and output_dir and os.path.isabs(url):
            try:
                url = os.path.relpath(url, output_dir)
            except ValueError:
                pass
    return url.replace("\\", "/") if url else ""


def _texture_xml(texture_ref, indent, *, container_field, output_dir=None, defs: "_DefNames | None" = None):
    """An ImageTexture for ``texture_ref``. With ``defs``, the first texture for a url (and wrap mode) gets a DEF and
    later ones a USE with their own containerField, so an image shared by several materials, in any role, is loaded
    once (Web3D's X3D Schematron warns about repeated urls)."""
    url = _texture_url(texture_ref, output_dir=output_dir)
    if not url:
        return ""
    clip = texture_ref.extension == "CLIP"
    attrs = ""
    if defs is not None:
        key = f"{url}|{'clip' if clip else 'repeat'}"
        texture_def = defs.get("texture", key, "TX_", label=os.path.splitext(os.path.basename(url))[0])
        if not defs.first_use("texture", key):
            return f'{indent}<ImageTexture USE="{texture_def}" containerField="{container_field}" />\n'
        attrs = f' DEF="{texture_def}"'
    xml = f"{indent}<ImageTexture{attrs} containerField=\"{container_field}\" url='{_mfstring([url])}'"
    if clip:
        xml += ' repeatS="false" repeatT="false"'
    xml += " />\n"
    return xml


def _texture_transform_xml(material, indent):
    """Appearance-level TextureTransform taken from the first mapped texture."""
    for _container_field, texture_ref in material.texture_refs():
        transform = texture_ref.transform
        if transform is None:
            continue
        if (
            tuple(transform.translation) == (0.0, 0.0)
            and float(transform.rotation) == 0.0
            and tuple(transform.scale) == (1.0, 1.0)
        ):
            continue
        return (
            f'{indent}<TextureTransform translation="{_fmt2(transform.translation)}" '
            f'rotation="{_fmt(transform.rotation)}" scale="{_fmt2(transform.scale)}" />\n'
        )
    return ""


def _classic_material_xml(material, material_def, indent, look: _Look, *, output_dir=None, defs=None):
    """``(material xml, appearance texture xml)`` of a Material written for ``material``. The base colour texture goes in
    the Appearance's texture field, the way a classic file has it (X3D 17.2.2: an RGB texture replaces diffuseColor)."""
    alpha = material.base_color[3] if len(material.base_color) > 3 else 1.0
    transparency = max(0.0, min(1.0, 1.0 - alpha))
    shininess, specular = phong_from_principled(material.roughness, material.specular_level, material.specular_tint)
    space = look.colour_space
    attrs = ([f'DEF="{material_def}"'] if material_def else []) + [
             f'diffuseColor="{_fmt3(_sfcolor(display_colour(material.base_color[:3], space)))}"']
    if max(specular) > 0.0005:
        attrs.append(f'specularColor="{_fmt3(_sfcolor(display_colour(specular, space)))}"')
    if abs(shininess - 0.2) > 0.0005:
        attrs.append(f'shininess="{_fmt(shininess)}"')
    if any(channel > 0.0 for channel in material.emissive_color[:3]):
        attrs.append(f'emissiveColor="{_fmt3(_sfcolor(display_colour(_sfcolor(material.emissive_color), space)))}"')
    if transparency > 0.0:
        attrs.append(f'transparency="{_fmt(transparency)}"')
    if material.normal_scale is not None and material.normal_scale != 1.0:
        attrs.append(f'normalScale="{_fmt(material.normal_scale)}"')
    if material.occlusion_strength is not None and material.occlusion_strength != 1.0:
        attrs.append(f'occlusionStrength="{_fmt(material.occlusion_strength)}"')
    inner = "".join(
        _texture_xml(ref, indent + "  ", container_field=field, output_dir=output_dir, defs=defs)
        for field, ref in (("emissiveTexture", material.emissive_texture), ("normalTexture", material.normal_texture),
                           ("occlusionTexture", material.occlusion_texture))
        if ref is not None
    )
    if inner:
        xml = f"{indent}<Material {' '.join(attrs)}>\n{inner}{indent}</Material>\n"
    else:
        xml = f"{indent}<Material {' '.join(attrs)} />\n"
    texture = ""
    if material.base_color_texture is not None:
        texture = _texture_xml(material.base_color_texture, indent, container_field="texture", output_dir=output_dir,
                               defs=defs)
    return xml, texture


def _material_xml(material, material_def, indent, *, output_dir=None, defs=None):
    tag = "UnlitMaterial" if material.unlit else "PhysicalMaterial"
    alpha = material.base_color[3] if len(material.base_color) > 3 else 1.0
    transparency = max(0.0, min(1.0, 1.0 - alpha))
    attrs = [f'DEF="{material_def}"'] if material_def else []
    textures = []

    if material.unlit:
        attrs.append(f'emissiveColor="{_fmt3(_sfcolor(material.emissive_color))}"')
        if transparency > 0.0:
            attrs.append(f'transparency="{_fmt(transparency)}"')
        if material.normal_scale is not None and material.normal_scale != 1.0:
            attrs.append(f'normalScale="{_fmt(material.normal_scale)}"')
        emissive_ref = material.emissive_texture or material.base_color_texture
        if emissive_ref is not None:
            textures.append(("emissiveTexture", emissive_ref))
        if material.normal_texture is not None:
            textures.append(("normalTexture", material.normal_texture))
    else:
        attrs.append(f'baseColor="{_fmt3(_sfcolor(material.base_color))}"')
        if material.metallic is not None:
            attrs.append(f'metallic="{_fmt(material.metallic)}"')
        if material.roughness is not None:
            attrs.append(f'roughness="{_fmt(material.roughness)}"')
        if material.normal_scale is not None and material.normal_scale != 1.0:
            attrs.append(f'normalScale="{_fmt(material.normal_scale)}"')
        if material.occlusion_strength is not None and material.occlusion_strength != 1.0:
            attrs.append(f'occlusionStrength="{_fmt(material.occlusion_strength)}"')
        if any(channel != 0.0 for channel in material.emissive_color[:3]):
            attrs.append(f'emissiveColor="{_fmt3(_sfcolor(material.emissive_color))}"')
        if transparency > 0.0:
            attrs.append(f'transparency="{_fmt(transparency)}"')
        textures.extend(material.texture_refs())

    texture_xml = "".join(
        _texture_xml(texture_ref, indent + "  ", container_field=container_field, output_dir=output_dir, defs=defs)
        for container_field, texture_ref in textures
    )
    if texture_xml:
        return f"{indent}<{tag} {' '.join(attrs)}>\n{texture_xml}{indent}</{tag}>\n"
    return f"{indent}<{tag} {' '.join(attrs)} />\n"


def _appearance_xml(material, defs: _DefNames, indent, *, output_dir=None, look: _Look = _PLAIN_LOOK, line_width=None):
    """The Appearance of ``material``. ``line_width`` (a LineProperties linewidthScaleFactor) gives the line shapes of
    that width an Appearance of their own, with the material written again without a DEF, since a LineProperties is part
    of the Appearance a shape shares."""
    key = material.name if line_width is None else f"{material.name}@lw{_fmt_short(line_width)}"
    app_def = defs.get("appearance", key, "APP_")
    if not defs.first_use("appearance", key):
        return f'{indent}<Appearance USE="{app_def}" />\n'
    material_def = defs.get("material", material.name, "MA_") if line_width is None else None
    attrs = [f'DEF="{app_def}"']
    if material.alpha_mode == "BLEND":
        attrs.append('alphaMode="BLEND"')
    elif material.alpha_mode == "MASK":
        attrs.append('alphaMode="MASK"')
        if material.alpha_cutoff is not None:
            attrs.append(f'alphaCutoff="{_fmt(material.alpha_cutoff)}"')
    xml = [f"{indent}<Appearance {' '.join(attrs)}>\n"]
    if _is_classic(material, look):
        material_xml, texture_xml = _classic_material_xml(material, material_def, indent + "  ", look, output_dir=output_dir,
                                                          defs=defs)
        xml.append(material_xml)
        xml.append(texture_xml)
    else:
        xml.append(_material_xml(material, material_def, indent + "  ", output_dir=output_dir, defs=defs))
    xml.append(_texture_transform_xml(material, indent + "  "))
    if line_width is not None:
        xml.append(f'{indent}  <LineProperties linewidthScaleFactor="{_fmt_short(line_width)}" />\n')
    xml.append(f"{indent}</Appearance>\n")
    return "".join(xml)


def _default_appearance_xml(indent, look: _Look = _PLAIN_LOOK):
    if look.classic:
        grey = _fmt3(display_colour((0.8, 0.8, 0.8), look.colour_space))
        return f'{indent}<Appearance>\n{indent}  <Material diffuseColor="{grey}" />\n{indent}</Appearance>\n'
    return (
        f"{indent}<Appearance>\n"
        f'{indent}  <PhysicalMaterial baseColor="0.800000 0.800000 0.800000" metallic="0.000000" roughness="0.500000" />\n'
        f"{indent}</Appearance>\n"
    )


# ---------------------------------------------------------------------------
# Geometry


def _point_set_xml(geometry, geometry_def, indent):
    """A vertices-only mesh: a PointSet with one Color / ColorRGBA per point when it has POINT colours."""
    xml = [f'{indent}<PointSet DEF="{geometry_def}">\n',
           f'{indent}  <Coordinate point="{" ".join(_fmt3_length(point) for point in geometry.coord)}" />\n']
    if geometry.color and len(geometry.color) == len(geometry.coord):
        if any(len(color) > 3 and color[3] < 1.0 for color in geometry.color):
            values = " ".join(_fmt4(_unit_rgba(color)) for color in geometry.color)
            xml.append(f'{indent}  <ColorRGBA color="{values}" />\n')
        else:
            values = " ".join(_fmt3(_sfcolor(color[:3])) for color in geometry.color)
            xml.append(f'{indent}  <Color color="{values}" />\n')
    xml.append(f"{indent}</PointSet>\n")
    return "".join(xml)


def _geometry_xml(geometry, defs: _DefNames, indent):
    geometry_def = defs.get("geometry", geometry.name, "ME_")
    node = "PointSet" if geometry.is_points else "IndexedLineSet" if geometry.is_lines else "IndexedFaceSet"
    if not defs.first_use("geometry", geometry.name):
        return f'{indent}<{node} USE="{geometry_def}" />\n'
    if geometry.is_points:
        return _point_set_xml(geometry, geometry_def, indent)
    if geometry.is_lines:
        xml = [
            f'{indent}<IndexedLineSet DEF="{geometry_def}" coordIndex="{_fmt_ints(geometry.coord_index)}">\n',
            f'{indent}  <Coordinate point="{_fmt_points(geometry.coord)}" />\n',
        ]
        if geometry.color and len(geometry.color) == len(geometry.coord):
            # one colour per vertex, which X3D draws in place of the material's emissiveColor (a Color node: colorIndex
            # follows coordIndex); ColorRGBA only when an alpha is below 1
            if any(len(color) > 3 and color[3] < 1.0 for color in geometry.color):
                values = " ".join(_fmt4(_unit_rgba(color)) for color in geometry.color)
                xml.append(f'{indent}  <ColorRGBA color="{values}" />\n')
            else:
                values = " ".join(_fmt3(_sfcolor(color[:3])) for color in geometry.color)
                xml.append(f'{indent}  <Color color="{values}" />\n')
        xml.append(f"{indent}</IndexedLineSet>\n")
        return "".join(xml)
    attrs = [f'DEF="{geometry_def}"', f'coordIndex="{_fmt_ints(geometry.coord_index)}"']
    if not geometry.solid:
        attrs.append('solid="false"')
    if geometry.crease_angle is not None and geometry.crease_angle > 0.0:
        attrs.append(f'creaseAngle="{_fmt(geometry.crease_angle)}"')
    xml = [f"{indent}<IndexedFaceSet {' '.join(attrs)}>\n"]
    if geometry.skin_coord_def:
        xml.append(f'{indent}  <Coordinate USE="{geometry.skin_coord_def}" />\n')
    elif geometry.morph_keys:
        coord_def = defs.get("coord", geometry.name, "CO_")
        xml.append(
            f'{indent}  <Coordinate DEF="{coord_def}" '
            f'point="{_fmt_points(geometry.morph_states[0])}" />\n'
        )
    else:
        xml.append(f'{indent}  <Coordinate point="{_fmt_points(geometry.coord)}" />\n')
    if geometry.normal:
        xml.append(f'{indent}  <Normal vector="{" ".join(_fmt3(vector) for vector in geometry.normal)}" />\n')
    if geometry.tex_coord:
        xml.append(
            f'{indent}  <TextureCoordinate point="{" ".join(_fmt2(point) for point in geometry.tex_coord)}" />\n'
        )
    if geometry.color:
        xml.append(f'{indent}  <ColorRGBA color="{" ".join(_fmt4(_unit_rgba(color)) for color in geometry.color)}" />\n')
    xml.append(f"{indent}</IndexedFaceSet>\n")
    return "".join(xml)


def _imported_primitive_xml(primitive, defs: _DefNames, indent):
    """An imported Box, Sphere, Cylinder or Cone written back as that node (extract.primitive_for_mesh), DEF on its
    first use and USE after, one per Blender mesh and solid (the way the import shared it). Fields at their X3D
    default are left out."""
    node, fields = primitive["node"], primitive["fields"]
    key = f'{primitive.get("mesh") or id(primitive)}{"" if fields.get("solid", True) else "_2s"}'
    primitive_def = defs.get("primitive", key, "GE_")
    if not defs.first_use("primitive", key):
        return f'{indent}<{node} USE="{primitive_def}" />\n'
    attrs = [f'DEF="{primitive_def}"']
    if node == "Box":
        size = tuple(float(v) for v in fields.get("size", (2.0, 2.0, 2.0)))
        if size != (2.0, 2.0, 2.0):
            attrs.append(f'size="{_fmt3_length(size)}"')
    elif node == "Sphere":
        if float(fields.get("radius", 1.0)) != 1.0:
            attrs.append(f'radius="{_fmt_length(float(fields["radius"]))}"')
    else:
        radius_field = "bottomRadius" if node == "Cone" else "radius"
        if float(fields.get(radius_field, 1.0)) != 1.0:
            attrs.append(f'{radius_field}="{_fmt_length(float(fields[radius_field]))}"')
        if float(fields.get("height", 2.0)) != 2.0:
            attrs.append(f'height="{_fmt_length(float(fields["height"]))}"')
        for flag in (("bottom", "side", "top") if node == "Cylinder" else ("bottom", "side")):
            if not fields.get(flag, True):
                attrs.append(f'{flag}="false"')
    if not fields.get("solid", True):
        attrs.append('solid="false"')
    return f'{indent}<{node}{"".join(" " + a for a in attrs)} />\n'


def _primitive_geometry_xml(hint, indent):
    if hint == "Box":
        return f'{indent}<Box size="1.000000 1.000000 1.000000" />\n'
    if hint == "Cone":
        return f'{indent}<Cone bottomRadius="0.500000" height="1.000000" />\n'
    if hint == "Cylinder":
        return f'{indent}<Cylinder radius="0.500000" height="1.000000" />\n'
    if hint == "Rectangle2D":
        return f'{indent}<Rectangle2D size="1.000000 1.000000" />\n'
    if hint == "Circle2D":
        return f'{indent}<Circle2D radius="0.500000" />\n'
    return f'{indent}<Sphere radius="0.750000" />\n'


# ---------------------------------------------------------------------------
# Scene


def _light_xml(light, defs: _DefNames, indent):
    light_def = defs.get("light", light.name, "LA_")
    attrs = [
        f'DEF="{light_def}"',
        f'color="{_fmt3(light.color)}"',
        f'intensity="{_fmt(light.intensity)}"',
        f'ambientIntensity="{_fmt(light.ambient_intensity)}"',
        # Each light sits inside its object's Transform. X3D scopes a light whose global field is FALSE to the
        # siblings in its parent group (DirectionalLight's default), which here is nothing, so it would light no
        # geometry. Blender lights illuminate the whole scene, so say so explicitly for every light type, except a
        # light that lit nothing in the file it was imported from (IRLight.scoped), which stays out of the scene's light.
        f'global="{"false" if light.scoped else "true"}"',
    ]
    if light.shadows:
        attrs.append('shadows="true"')
    if light.shadow_intensity is not None:
        attrs.append(f'shadowIntensity="{_fmt(light.shadow_intensity)}"')
    if light.light_type == "DIRECTIONAL":
        attrs.append(f'direction="{_fmt3(light.direction)}"')
        return f"{indent}<DirectionalLight {' '.join(attrs)} />\n"
    attrs.append(f'location="{_fmt3(light.location)}"')
    if light.attenuation is not None:
        attrs.append('attenuation="%s"' % " ".join("%.9g" % a for a in light.attenuation))   # small a2 stays
    if light.radius is not None:
        attrs.append(f'radius="{_fmt(light.radius)}"')
    if light.light_type == "SPOT":
        attrs.append(f'direction="{_fmt3(light.direction)}"')
        if light.beam_width is not None:
            attrs.append(f'beamWidth="{_fmt(light.beam_width)}"')
        if light.cut_off_angle is not None:
            attrs.append(f'cutOffAngle="{_fmt(light.cut_off_angle)}"')
        return f"{indent}<SpotLight {' '.join(attrs)} />\n"
    return f"{indent}<PointLight {' '.join(attrs)} />\n"


def _viewpoint_xml(viewpoint, defs: _DefNames, indent):
    view_def = defs.get("viewpoint", viewpoint.name or viewpoint.description or "Viewpoint", "CA_")
    attrs = [f'DEF="{view_def}"']
    if viewpoint.description:
        attrs.append(f"description={quoteattr(viewpoint.description)}")
    attrs.append(f'position="{_fmt3(viewpoint.transform.translation)}"')
    attrs.append(f'orientation="{_fmt4(viewpoint.transform.rotation_axis_angle)}"')
    if viewpoint.field_of_view is not None:
        attrs.append(f'fieldOfView="{_fmt(viewpoint.field_of_view)}"')
    if viewpoint.near_distance is not None:
        attrs.append(f'nearDistance="{_fmt_length(viewpoint.near_distance)}"')
    if viewpoint.far_distance is not None:
        attrs.append(f'farDistance="{_fmt_length(viewpoint.far_distance)}"')
    return f"{indent}<Viewpoint {' '.join(attrs)} />\n"


# Upper limits of Background skyAngle and groundAngle in the X3D 4.0 schema and object model: pi and pi/2, rounded up.
_SKY_ANGLE_MAX = 3.1416
_GROUND_ANGLE_MAX = 1.5708


def _background_xml(background, indent):
    """A Background with its sky and ground gradients. Colours are clipped to [0, 1] and angles to the ranges the
    X3D 4.0 schema gives; each angle list is cut to one less than its colours, and the colours to one more than
    the angles."""

    def clip(values, top):
        return [min(max(float(value), 0.0), top) for value in values]

    sky_color = [tuple(clip(color, 1.0)) for color in background.sky_color] or [(0.0, 0.0, 0.0)]
    sky_angle = clip(background.sky_angle, _SKY_ANGLE_MAX)[:len(sky_color) - 1]
    sky_color = sky_color[:len(sky_angle) + 1]
    ground_color = [tuple(clip(color, 1.0)) for color in background.ground_color]
    ground_angle = clip(background.ground_angle, _GROUND_ANGLE_MAX)[:max(len(ground_color) - 1, 0)]
    ground_color = ground_color[:len(ground_angle) + 1]
    attrs = []
    if sky_angle:
        attrs.append(f'skyAngle="{" ".join(_fmt(angle) for angle in sky_angle)}"')
    attrs.append(f'skyColor="{" ".join(_fmt3(color) for color in sky_color)}"')
    if ground_angle:
        attrs.append(f'groundAngle="{" ".join(_fmt(angle) for angle in ground_angle)}"')
    if ground_color:
        attrs.append(f'groundColor="{" ".join(_fmt3(color) for color in ground_color)}"')
    transparency = clip([background.transparency], 1.0)[0]
    if transparency:
        attrs.append(f'transparency="{_fmt(transparency)}"')
    return f"{indent}<Background {' '.join(attrs)} />\n"


def _metadata_xml(node, indent, container_field=None):
    """A Metadata* node. Inside a MetadataSet the X3D 4.0 default containerField, value, applies; a node's own
    metadata field needs containerField="metadata"."""
    attrs = [f'containerField="{container_field}"'] if container_field else []
    if node.name is not None:
        attrs.append(f"name={quoteattr(node.name)}")
    if node.reference is not None:
        attrs.append(f"reference={quoteattr(node.reference)}")
    if node.node_type != "MetadataSet":
        if node.value is not None:
            attrs.append(f"value={quoteattr(node.value)}")
        return f"{indent}<{node.node_type} {' '.join(attrs)} />\n"
    if not node.members:
        return f"{indent}<MetadataSet {' '.join(attrs)} />\n"
    members = "".join(_metadata_xml(member, indent + "  ") for member in node.members)
    return f"{indent}<MetadataSet {' '.join(attrs)}>\n{members}{indent}</MetadataSet>\n"


def _subtree_hidden(instance):
    return not instance.visible and all(_subtree_hidden(child) for child in instance.children)


def _instance_xml(instance, geometries, materials, defs: _DefNames, indent, *, output_dir=None, humanoids=None,
                  splats=None, version="4.0", look: _Look = _PLAIN_LOOK, collections=None):
    humanoids = humanoids or {}
    collections = collections or {}
    splats = splats or {}
    tx, ty, tz = instance.transform.translation
    rx, ry, rz, ra = instance.transform.rotation_axis_angle
    sx, sy, sz = instance.transform.scale
    transform_def = defs.get("transform", instance.object_name, "OB_")
    # visible="false" on a Transform hides its whole subtree: only write it there when every descendant is hidden too,
    # else hide just this object's own Shapes
    subtree_hidden = _subtree_hidden(instance)
    visible_attr = ' visible="false"' if subtree_hidden else ""
    xml = [
        f'{indent}<Transform DEF="{transform_def}" '
        f'translation="{_fmt3_length((tx, ty, tz))}" '
        f'rotation="{_fmt4((rx, ry, rz, ra))}" '
        f'scale="{_fmt3_length((sx, sy, sz))}"{visible_attr}>\n'
    ]
    if instance.interaction is not None:
        xml.append(_sensor_xml(instance, defs, indent + "  "))
    shape_attrs = "" if instance.cast_shadow else ' castShadow="false"'
    if not instance.visible and not subtree_hidden:
        shape_attrs += ' visible="false"'
    for index, shape in enumerate(instance.iter_shapes()):
        xml.append(f"{indent}  <Shape{shape_attrs}>\n")
        if index == 0 and instance.metadata is not None:
            xml.append(_metadata_xml(instance.metadata, indent + "    ", "metadata"))
        material = materials.get(shape.material_name) if shape.material_name else None
        geometry = geometries.get(shape.geometry_name) if shape.geometry_name else None
        line_width = instance.line_width if geometry is not None and geometry.is_lines else None
        if material is not None:
            xml.append(_appearance_xml(material, defs, indent + "    ", output_dir=output_dir, look=look,
                                       line_width=line_width))
        else:
            xml.append(_default_appearance_xml(indent + "    ", look))
        if geometry is not None:
            xml.append(_geometry_xml(geometry, defs, indent + "    "))
        elif shape.primitive:
            xml.append(_imported_primitive_xml(shape.primitive, defs, indent + "    "))
        else:
            xml.append(_primitive_geometry_xml(shape.geometry_hint, indent + "    "))
        xml.append(f"{indent}  </Shape>\n")
    if instance.humanoid_name and instance.humanoid_name in humanoids:
        humanoid = humanoids[instance.humanoid_name]
        placed = type(humanoid)(name=humanoid.name, root_joints=humanoid.root_joints,
                                standard_joint_count=humanoid.standard_joint_count,
                                skin_coord=humanoid.skin_coord, skin_shapes=humanoid.skin_shapes)
        xml.append(_humanoid_xml(placed, geometries, materials, defs, indent + "  ", output_dir=output_dir, look=look))
    if instance.inline is not None:
        inline_def = defs.get("inline", instance.object_name, "IN_")
        xml.append(f"{indent}  <Inline DEF=\"{inline_def}\" url='{_mfstring([instance.inline.url])}' />\n")
    if instance.splats_name and instance.splats_name in splats:
        xml.append(_splats_xml(splats[instance.splats_name], defs, indent + "  ", version=version,
                               output_dir=output_dir))
    if instance.collection_name and instance.collection_name in collections:
        group_def = defs.get("collection", instance.collection_name, "CO_")
        if defs.first_use("collection", instance.collection_name):
            xml.append(f'{indent}  <Group DEF="{group_def}">\n')
            for member in collections[instance.collection_name]:
                xml.append(_instance_xml(member, geometries, materials, defs, indent + "    ", output_dir=output_dir,
                                         humanoids=humanoids, splats=splats, version=version, look=look,
                                         collections=collections))
            xml.append(f"{indent}  </Group>\n")
        else:
            xml.append(f'{indent}  <Group USE="{group_def}" />\n')
    if instance.light is not None:
        xml.append(_light_xml(instance.light, defs, indent + "  "))
    if instance.viewpoint is not None:
        xml.append(_viewpoint_xml(instance.viewpoint, defs, indent + "  "))
    for child in instance.children:
        xml.append(_instance_xml(child, geometries, materials, defs, indent + "  ", output_dir=output_dir, humanoids=humanoids,
                                 splats=splats, version=version, look=look, collections=collections))
    xml.append(f"{indent}</Transform>\n")
    return "".join(xml)


def _joint_def(defs: _DefNames, humanoid_name, joint_name):
    return defs.get("joint", f"{humanoid_name}:{joint_name}", "hanim_")


def _joint_xml(joint, humanoid_name, defs: _DefNames, indent, *, container_field="children"):
    joint_def = _joint_def(defs, humanoid_name, joint.name)
    attrs = [f'DEF="{joint_def}"', f"name={quoteattr(joint.hanim_name or joint.name)}", f'center="{_fmt3(joint.center)}"']
    if container_field != "children":
        attrs.append(f'containerField="{container_field}"')
    if joint.skin_coord_index:
        attrs.append(f'skinCoordIndex="{_fmt_ints(joint.skin_coord_index)}"')
        attrs.append(f'skinCoordWeight="{" ".join(_fmt(weight) for weight in joint.skin_coord_weight)}"')
    if not joint.children:
        return f"{indent}<HAnimJoint {' '.join(attrs)} />\n"
    xml = [f"{indent}<HAnimJoint {' '.join(attrs)}>\n"]
    for child in joint.children:
        xml.append(_joint_xml(child, humanoid_name, defs, indent + "  "))
    xml.append(f"{indent}</HAnimJoint>\n")
    return "".join(xml)


def _humanoid_info_attr(humanoid):
    return f"info='{_humanoid_info(humanoid)}' " if humanoid.standard_joint_count else ""


def _humanoid_info(humanoid):
    total = sum(1 for _ in humanoid.iter_joints())
    return _mfstring([f"{humanoid.standard_joint_count} of {total} joints carry standard H-Anim 2.0 names; the rest keep "
                      "their Blender bone names", "exported by X3D Blender I/O"])


def _humanoid_xml(humanoid, geometries, materials, defs: _DefNames, indent, *, output_dir=None, look: _Look = _PLAIN_LOOK):
    humanoid_def = defs.get("humanoid", humanoid.name, "hanim_")
    tx = humanoid.transform
    xml = [
        f'{indent}<HAnimHumanoid DEF="{humanoid_def}" name={quoteattr(humanoid.name)} version="2.0" '
        f"{_humanoid_info_attr(humanoid)}"
        f'skeletalConfiguration="BLENDER" '
        f'translation="{_fmt3_length(tx.translation)}" rotation="{_fmt4(tx.rotation_axis_angle)}" '
        f'scale="{_fmt3_length(tx.scale)}">\n'
    ]
    for root in humanoid.root_joints:
        xml.append(_joint_xml(root, humanoid.name, defs, indent + "  ", container_field="skeleton"))
    for joint in humanoid.iter_joints():
        xml.append(f'{indent}  <HAnimJoint USE="{_joint_def(defs, humanoid.name, joint.name)}" containerField="joints" />\n')
    if humanoid.skin_coord:
        skin_def = next((geometries[s.geometry_name].skin_coord_def for s in humanoid.skin_shapes
                         if s.geometry_name in geometries and geometries[s.geometry_name].skin_coord_def), None)
        if skin_def:
            xml.append(
                f'{indent}  <Coordinate DEF="{skin_def}" containerField="skinCoord" '
                f'point="{_fmt_points(humanoid.skin_coord)}" />\n'
            )
    for shape in humanoid.skin_shapes:
        xml.append(f'{indent}  <Shape containerField="skin">\n')
        material = materials.get(shape.material_name) if shape.material_name else None
        if material is not None:
            xml.append(_appearance_xml(material, defs, indent + "    ", output_dir=output_dir, look=look))
        else:
            xml.append(_default_appearance_xml(indent + "    ", look))
        geometry = geometries.get(shape.geometry_name)
        if geometry is not None:
            xml.append(_geometry_xml(geometry, defs, indent + "    "))
        xml.append(f"{indent}  </Shape>\n")
    xml.append(f"{indent}</HAnimHumanoid>\n")
    return "".join(xml)


# A TimeSensor that only a trigger should start: with the default startTime 0 and loop false, a browser sees a cycle that
# ended long ago and sends fraction_changed 1 at load, which parks every targeted object (and the tour rig) at the END of
# its animation (X_ITE 16.7.1 did exactly that). A startTime far in the future keeps it silent until a ROUTE sets it.
_NEVER_STARTED = "1e+30"


def _triggered_targets(ir_scene):
    """Objects whose animation an authored trigger plays: they get a timer of their own instead of the scene's."""
    return {instance.interaction.target for instance in ir_scene.iter_instances()
            if instance.interaction is not None and instance.interaction.action == "animate"}


def _trigger_timer_def(defs: _DefNames, target):
    return defs.get("trigtimer", target, "TT_")


def _animation_xml(ir_scene, defs: _DefNames, indent):
    morphs = [g for g in ir_scene.geometries if g.morph_keys and ("geometry", g.name) in defs.emitted]
    if not ir_scene.animations and not morphs:
        return ""
    cycle = ir_scene.cycle_interval or 1.0
    triggered = _triggered_targets(ir_scene)
    timer_def = defs.get("timer", "SceneTimer", "")
    xml = []
    free_running = bool(morphs) or any(
        a.target_kind != "transform" or a.target not in triggered for a in ir_scene.animations)
    if free_running:
        xml.append(f'{indent}<TimeSensor DEF="{timer_def}" cycleInterval="{_fmt(cycle)}" loop="true" />\n')
    for target in sorted(triggered):
        if any(a.target == target and a.target_kind == "transform" for a in ir_scene.animations):
            xml.append(f'{indent}<TimeSensor DEF="{_trigger_timer_def(defs, target)}" cycleInterval="{_fmt(cycle)}" '
                       f'loop="false" startTime="{_NEVER_STARTED}" />\n')
    routes = []
    shared: dict[tuple, list] = {}  # geometries with the same keys and states share one CoordinateInterpolator
    for geometry in morphs:
        signature = (tuple(geometry.morph_keys), hash(tuple(tuple(state) for state in geometry.morph_states)))
        for owner in shared.get(signature, []):
            if owner.morph_keys == geometry.morph_keys and owner.morph_states == geometry.morph_states:
                routes.append((defs.get("coord_interpolator", owner.name, "CI_"), "value_changed",
                               defs.get("coord", geometry.name, "CO_"), "set_point"))
                break
        else:
            shared.setdefault(signature, []).append(geometry)
            node_def = defs.get("coord_interpolator", geometry.name, "CI_")
            keys = " ".join(_fmt_short(key) for key in geometry.morph_keys)
            values = " ".join(_fmt_short_length(value) for state in geometry.morph_states for point in state for value in point)
            xml.append(f'{indent}<CoordinateInterpolator DEF="{node_def}" key="{keys}" keyValue="{values}" />\n')
            routes.append((timer_def, "fraction_changed", node_def, "set_fraction"))
            routes.append((node_def, "value_changed", defs.get("coord", geometry.name, "CO_"), "set_point"))
    for animation in ir_scene.animations:
        if animation.target_kind == "joint":
            humanoid_name, _, joint_name = animation.target.partition(":")
            target_def = _joint_def(defs, humanoid_name, joint_name)
        else:
            target_def = defs.get("transform", animation.target, "OB_")
        keys = " ".join(_fmt(key) for key in animation.keys)
        safe_target = _safe_name(animation.target)
        timer_def = (_trigger_timer_def(defs, animation.target)
                     if animation.target_kind == "transform" and animation.target in triggered else defs.get("timer", "SceneTimer", ""))
        if animation.translations:
            node_def = f"PI_{safe_target}"
            xml.append(
                f'{indent}<PositionInterpolator DEF="{node_def}" key="{keys}" '
                f'keyValue="{" ".join(_fmt3_length(value) for value in animation.translations)}" />\n'
            )
            routes.append((timer_def, "fraction_changed", node_def, "set_fraction"))
            routes.append((node_def, "value_changed", target_def, "set_translation"))
        if animation.rotations:
            node_def = f"OI_{safe_target}"
            xml.append(
                f'{indent}<OrientationInterpolator DEF="{node_def}" key="{keys}" '
                f'keyValue="{" ".join(_fmt4(value) for value in animation.rotations)}" />\n'
            )
            routes.append((timer_def, "fraction_changed", node_def, "set_fraction"))
            routes.append((node_def, "value_changed", target_def, "set_rotation"))
        if animation.scales:
            node_def = f"SI_{safe_target}"
            xml.append(
                f'{indent}<PositionInterpolator DEF="{node_def}" key="{keys}" '
                f'keyValue="{" ".join(_fmt3_length(value) for value in animation.scales)}" />\n'
            )
            routes.append((timer_def, "fraction_changed", node_def, "set_fraction"))
            routes.append((node_def, "value_changed", target_def, "set_scale"))
    for from_node, from_field, to_node, to_field in routes:
        xml.append(
            f'{indent}<ROUTE fromNode="{from_node}" fromField="{from_field}" '
            f'toNode="{to_node}" toField="{to_field}" />\n'
        )
    return "".join(xml)


def _sensor_def(defs: _DefNames, instance):
    prefix = "TS_" if instance.interaction.trigger == "click" else "PS_"
    return defs.get("sensor", instance.object_name, prefix)


def _sensor_xml(instance, defs: _DefNames, indent):
    """The TouchSensor or ProximitySensor an object's x3d_trigger asks for, written inside its Transform."""
    interaction = instance.interaction
    description = quoteattr(f"{interaction.action} {interaction.target}".strip())
    if interaction.trigger == "click":
        return f'{indent}<TouchSensor DEF="{_sensor_def(defs, instance)}" description={description} />\n'
    # the sensor sits inside the object's Transform, so the object's scale would scale the box: divide it back out so
    # the box is 2 x radius in world units (rotation still turns it with the object)
    size = " ".join(_fmt_short(2.0 * interaction.radius / max(abs(axis), 1e-6)) for axis in instance.transform.scale)
    return (f'{indent}<ProximitySensor DEF="{_sensor_def(defs, instance)}" description={description} '
            f'center="0 0 0" size="{size}" />\n')


def _tour_xml(tour, defs: _DefNames, indent):
    """The tour rig (a Transform carrying one Viewpoint), its timer and interpolators, and their ROUTEs."""
    keys, total = tour_timeline(tour)
    rig_def = defs.get("transform", "TourRig", "")
    view_def = defs.get("viewpoint", "TourView", "")
    timer_def = defs.get("timer", "TourTimer", "")
    first = tour.stops[0]
    fov = f' fieldOfView="{_fmt(first.field_of_view)}"' if first.field_of_view is not None else ""
    positions, rotations, key_text = [], [], " ".join(_fmt(key) for key in keys)
    for stop in tour.stops:
        positions += [_fmt3_length(stop.transform.translation)] * 2
        rotations += [_fmt4(stop.transform.rotation_axis_angle)] * 2
    loop = tour.loop or tour.autostart
    start_attr = "" if tour.autostart else ' startTime="%s"' % _NEVER_STARTED
    xml = [
        f'{indent}<Transform DEF="{rig_def}" translation="{positions[0]}" rotation="{rotations[0]}">\n',
        f'{indent}  <Viewpoint DEF="{view_def}" description="Tour"{fov} />\n',
        f"{indent}</Transform>\n",
        f'{indent}<TimeSensor DEF="{timer_def}" cycleInterval="{_fmt(max(total, 1e-3))}" loop="{"true" if loop else "false"}"'
        f'{start_attr} />\n',
        f'{indent}<PositionInterpolator DEF="PI_TourRig" key="{key_text}" keyValue="{" ".join(positions)}" />\n',
        f'{indent}<OrientationInterpolator DEF="OI_TourRig" key="{key_text}" keyValue="{" ".join(rotations)}" />\n',
    ]
    routes = [
        (timer_def, "fraction_changed", "PI_TourRig", "set_fraction"),
        (timer_def, "fraction_changed", "OI_TourRig", "set_fraction"),
        ("PI_TourRig", "value_changed", rig_def, "set_translation"),
        ("OI_TourRig", "value_changed", rig_def, "set_rotation"),
        (timer_def, "isActive", view_def, "set_bind"),
    ]
    return "".join(xml), routes


def _interaction_xml(ir_scene, defs: _DefNames, indent):
    """The tour and the ROUTEs from every authored sensor to what it fires (timers come from _animation_xml)."""
    xml, routes = [], []
    if ir_scene.tour is not None and ir_scene.tour.stops:
        tour_text, tour_routes = _tour_xml(ir_scene.tour, defs, indent)
        xml.append(tour_text)
        routes += tour_routes
    animated = {a.target for a in ir_scene.animations if a.target_kind == "transform"}
    for instance in ir_scene.iter_instances():
        interaction = instance.interaction
        if interaction is None:
            continue
        sensor = _sensor_def(defs, instance)
        click = interaction.trigger == "click"
        if interaction.action == "animate" and interaction.target in animated:
            routes.append((sensor, "touchTime" if click else "enterTime",
                           _trigger_timer_def(defs, interaction.target), "set_startTime"))
        elif interaction.action == "tour":
            routes.append((sensor, "touchTime" if click else "enterTime",
                           defs.get("timer", "TourTimer", ""), "set_startTime"))
        elif interaction.action == "viewpoint":
            view_def = defs.get("viewpoint", interaction.target, "CA_")
            if click:
                # a press binds the camera; the release must not unbind it, so only the true edge goes on
                filter_def = defs.get("filter", instance.object_name, "BF_")
                xml.append(f'{indent}<BooleanFilter DEF="{filter_def}" />\n')
                routes.append((sensor, "isActive", filter_def, "set_boolean"))
                routes.append((filter_def, "inputTrue", view_def, "set_bind"))
            else:
                routes.append((sensor, "isActive", view_def, "set_bind"))
    for from_node, from_field, to_node, to_field in routes:
        xml.append(f'{indent}<ROUTE fromNode="{from_node}" fromField="{from_field}" '
                   f'toNode="{to_node}" toField="{to_field}" />\n')
    return "".join(xml)


_SH_FIELD = "sphericalHarmonicsDegree{degree}Coef{coef}"

_FLOAT32 = struct.Struct("<f")
_FLOAT32_MAX = 3.4028234663852886e38


def _float32(value: float) -> float:
    return _FLOAT32.unpack(_FLOAT32.pack(value))[0]


def _fmt_float32(value: float) -> str:
    """Shortest ``%g`` text (6 to 9 significant digits) that reads back as the same float32."""
    target = _float32(_finite(value))
    for digits in (6, 7, 8):
        text = "%.*g" % (digits, target)
        if _float32(float(text)) == target:
            return text
    return "%.9g" % target


def _fmt_exact(values, field: str, node: str) -> str:
    """Space-separated float32-exact text for a GaussianSplats array.

    Splat data is float32 everywhere it comes from (PLY, Blender attributes,
    trainers), and ``%.6f`` is absolute precision: small scales lost most of
    their digits and some rounded to 0. The shortest ``%g`` text that reads
    back as the same float32 costs a few percent more bytes and makes export
    then import bit-exact. Non-finite values would make the file invalid
    against the 4.1 schema, so they stop the export with a message instead.
    """
    flat = list(chain.from_iterable(values)) if values and isinstance(values[0], (tuple, list)) else list(values)
    bad = sum(1 for value in flat if not math.isfinite(value) or abs(value) > _FLOAT32_MAX)
    if bad:
        raise ValueError(f"GaussianSplats '{node}': {bad} non-finite or out-of-float32-range value(s) in {field}; clean the splat data before exporting")
    return " ".join(_fmt_float32(value) for value in flat)


def _splats_xml(splats, defs: _DefNames, indent, *, version="4.0", output_dir=None):
    """GaussianSplats node for X3D 4.1; a coloured PointSet for earlier versions; an Inline of a
    KHR_gaussian_splatting glb written beside the file when the object asked for one (any version)."""
    splats_def = defs.get("splats", splats.name, "GS_")
    if splats.glb_name and output_dir:
        if not defs.first_use("splatsglb", splats.name):
            return f'{indent}<Inline USE="{splats_def}" />\n'
        payload = splat_glb_bytes(splats)
        glb_name = defs.sidecar(splats.glb_name, hashlib.sha256(payload).hexdigest())
        with open(os.path.join(output_dir, glb_name), "wb") as handle:
            handle.write(payload)
        return f"{indent}<Inline DEF=\"{splats_def}\" url='\"{escape(glb_name)}\"' />\n"
    if version == "4.1":
        if not defs.first_use("splats", splats.name):
            return f'{indent}<GaussianSplats USE="{splats_def}" />\n'
        attrs = [f'DEF="{splats_def}"']
        if splats.color_space != "SRGB_REC709_DISPLAY":
            attrs.append(f'colorSpace="{escape(splats.color_space)}"')
        name = splats.name
        attrs.append(f'positions="{_fmt_exact([p[:3] for p in splats.positions], "positions", name)}"')
        if splats.scales:
            attrs.append(f'scales="{_fmt_exact([v[:3] for v in splats.scales], "scales", name)}"')
        if splats.orientations:
            attrs.append(f'orientations="{_fmt_exact([q[:4] for q in splats.orientations], "orientations", name)}"')
        if splats.opacities:
            attrs.append(f'opacities="{_fmt_exact(splats.opacities, "opacities", name)}"')
        for (degree, coef), values in sorted(splats.sh.items()):
            if values and degree <= splats.sh_degree():
                field = _SH_FIELD.format(degree=degree, coef=coef)
                attrs.append(f'{field}="{_fmt_exact([v[:3] for v in values], field, name)}"')
        return f"{indent}<GaussianSplats {' '.join(attrs)} />\n"
    # 4.0 fallback: centres as a PointSet with the reconstructed base colour
    xml = [f"{indent}<Shape>\n"]
    if not defs.first_use("splats", splats.name):
        xml.append(f'{indent}  <PointSet USE="{splats_def}" />\n')
    else:
        xml.append(f'{indent}  <PointSet DEF="{splats_def}">\n')
        xml.append(f'{indent}    <Coordinate point="{" ".join(_fmt3(p) for p in splats.positions)}" />\n')
        dc = splats.sh.get((0, 0))
        if dc:
            colors = (sh0_to_rgb(c) + (max(0.0, min(1.0, splats.opacities[i])) if i < len(splats.opacities) else 1.0,)
                      for i, c in enumerate(dc))
            xml.append(f'{indent}    <ColorRGBA color="{" ".join(_fmt4(c) for c in colors)}" />\n')
        xml.append(f"{indent}  </PointSet>\n")
    xml.append(f"{indent}</Shape>\n")
    return "".join(xml)


def _meta(name, content):
    return f"    <meta name={quoteattr(name)} content={quoteattr(str(content))} />\n"


# Head meta the export dialog can set, in the order they are written; all but reference take one value.
_DIALOG_META = ("title", "creator", "description", "keywords", "reference", "license")
_SINGLE_VALUED_META = frozenset(_DIALOG_META) - {"reference"}


def _tool_name(generator: str) -> str:
    """A generator string without its trailing version number, so two versions of one tool compare equal."""
    return re.sub(r"\s+v?\d[\w.+-]*$", "", generator.strip())


def head_meta(metadata: IRMetadata, generator: str, diagnostics=()) -> list[tuple[str, str]]:
    """The (name, content) pairs of the head's meta statements, in the order they are written.

    The generator and filename describe this export and come first. Meta read from an imported file follows in
    file order, repeated names included. A value set in the export dialog replaces the imported meta of that
    name, except reference, which is added to the imported ones. When the imported file was written by this
    exporter, its own generator, its ``info`` diagnostics and the licence "NONE" older versions wrote are left
    out: this export writes its own. A pair that repeats an earlier one exactly is written once.
    """
    own_tool = _tool_name(generator)

    def by_this_exporter(name, content):
        return name in ("generator", "translator") and _tool_name(content) == own_tool

    imported = list(metadata.entries)
    from_this_exporter = any(by_this_exporter(name, content) for name, content in imported)
    dialog = {name: getattr(metadata, name) for name in _DIALOG_META if getattr(metadata, name, None)}
    pairs = [("generator", generator)]
    if metadata.filename:
        pairs.append(("filename", metadata.filename))
    replaced = set()
    for name, content in imported:
        if name == "filename" or by_this_exporter(name, content):
            continue
        if from_this_exporter and (name == "info" or (name == "license" and content == "NONE")):
            continue
        if name in _SINGLE_VALUED_META and name in dialog:
            if name not in replaced:
                pairs.append((name, dialog[name]))
                replaced.add(name)
            continue
        pairs.append((name, content))
    pairs.extend((name, dialog[name]) for name in _DIALOG_META if name in dialog and name not in replaced)
    pairs.extend(("info", message) for message in diagnostics)
    unique = []
    for pair in pairs:
        if pair not in unique:
            unique.append(pair)
    return unique


def _components(ir_scene: IRScene, version: str) -> list[tuple[str, int]]:
    """(name, level) of every component statement the Immersive header needs, sorted by name.

    PhysicalMaterial (Shape 2) and UnlitMaterial (Shape 1) are left out of the
    Immersive node list in Annex E Table E.3 and in X3DUOM, although Table E.2
    gives Immersive Shape level 2; declaring Shape level 2 is conformant under
    both readings. Every Shape written for a mesh or a skin carries one of the
    two (the default appearance is a PhysicalMaterial); the 4.0 splat PointSet
    has no Appearance. Circle2D is Geometry2D level 2; Immersive has level 1.
    """
    components = {}
    if version == "4.1" and ir_scene.splats:
        components["GaussianSplats"] = 1
    if ir_scene.humanoids:
        components["HAnim"] = 1
    geometries = ir_scene.geometry_by_name()
    humanoids = {humanoid.name: humanoid for humanoid in ir_scene.humanoids}
    for instance in ir_scene.iter_instances():
        shapes = list(instance.iter_shapes())
        humanoid = humanoids.get(instance.humanoid_name)
        if shapes or (humanoid is not None and humanoid.skin_shapes):
            components["Shape"] = 2
        if any(shape.geometry_name not in geometries and shape.geometry_hint == "Circle2D" for shape in shapes):
            components["Geometry2D"] = 2
        interaction = instance.interaction
        if interaction is not None:
            # X_ITE 16.7.1 ignores a TouchSensor in a file that does not declare its component
            components["PointingDeviceSensor" if interaction.trigger == "click" else "EnvironmentalSensor"] = 1
            if interaction.trigger == "click" and interaction.action == "viewpoint":
                components["EventUtilities"] = 1
    return sorted(components.items())


def _geometries_by_material_kind(ir_scene: IRScene, display_materials=None) -> tuple[set, set]:
    """Names of the geometries drawn with a material whose colours X_ITE reads as display values (``display_materials``,
    by default the UnlitMaterials), and of those drawn with anything else."""
    unlit_materials = ({material.name for material in ir_scene.materials if material.unlit}
                       if display_materials is None else set(display_materials))
    unlit, other = set(), set()

    def visit(instances):
        for instance in instances:
            for shape in instance.iter_shapes():
                if shape.geometry_name:
                    (unlit if shape.material_name in unlit_materials else other).add(shape.geometry_name)
            visit(instance.children)

    visit(ir_scene.instances)
    for humanoid in ir_scene.humanoids:
        for shape in humanoid.skin_shapes:
            if shape.geometry_name:
                (unlit if shape.material_name in unlit_materials else other).add(shape.geometry_name)
    return unlit, other


def with_display_colours(ir_scene: IRScene, colour_space: str) -> IRScene:
    """``ir_scene`` with its UnlitMaterial colours in X3D's display encoding under ``colour_space`` 'SRGB'.

    X_ITE draws an UnlitMaterial emissiveColor of 0.5 as 128, in display space (measured 12 Nov 2026, X_ITE 16.7.1),
    while Blender holds linear colours, so they are sRGB-encoded. The per-vertex colours (ColorRGBA) of a geometry
    drawn only with an UnlitMaterial are encoded the same way: the importer turned such a Color into linear values
    (set_new_float_color_attribute), so writing them unchanged darkened every round trip (an aurora ribbon's
    0.456 0.086 0.599 came back as 0.176 0.008 0.317). The same holds for the vertex colours of geometry drawn only
    with a Material (the classic model, ``ir_scene.material_model``): X_ITE reads them as display values. The Material's
    own colours are encoded where it is written (_classic_material_xml). PhysicalMaterial colours, and the vertex
    colours of geometry drawn with one, stay linear: X_ITE lights them the glTF way and the importer keeps them as
    given. Under 'AS_IS' the scene is returned unchanged.
    """
    look = _Look(classic=ir_scene.material_model == "classic", colour_space=colour_space,
                 forced=ir_scene.material_model_forced)
    if colour_space != "SRGB" or not any(material.unlit or _is_classic(material, look) for material in ir_scene.materials):
        return ir_scene
    materials = []
    for material in ir_scene.materials:
        if material.unlit:
            colour = tuple(material.emissive_color)
            material = replace(material, emissive_color=display_colour(colour[:3], colour_space) + tuple(colour[3:]))
        materials.append(material)
    drawn_display = {m.name for m in ir_scene.materials if m.unlit or _is_classic(m, look)}
    shown, other = _geometries_by_material_kind(ir_scene, drawn_display)
    encode = shown - other
    geometries = [
        replace(geometry, color=[display_colour(c[:3], colour_space) + tuple(c[3:]) for c in geometry.color])
        if geometry.name in encode and geometry.color else geometry
        for geometry in ir_scene.geometries
    ]
    return replace(ir_scene, materials=materials, geometries=geometries)


def export_ir_scene(file, ir_scene: IRScene, *, generator: str = "io_scene_x3d", version: str = "4.0",
                    colour_space: str = "AS_IS") -> None:
    """Write ``ir_scene`` as an X3D 4.0 (or 4.1 draft) XML document to ``file``.

    With ``version`` "4.1" Gaussian splats are written as the GaussianSplats
    node (component GaussianSplats level 1); with "4.0" they degrade to a
    coloured PointSet and a diagnostic says so. ``colour_space`` 'SRGB' writes
    UnlitMaterial colours sRGB-encoded (see ``with_display_colours``).
    """
    if version not in {"4.0", "4.1"}:
        raise ValueError(f"Unsupported X3D version for the modern writer: {version!r}")
    nonfinite_before = nonfinite_count()
    ir_scene = with_display_colours(ir_scene, colour_space)
    look = _Look(classic=ir_scene.material_model == "classic", colour_space=colour_space,
                 forced=ir_scene.material_model_forced)
    diagnostics = list(ir_scene.diagnostics)
    if version == "4.0" and ir_scene.splats:
        diagnostics.append(
            f"{len(ir_scene.splats)} Gaussian splat object(s) written as PointSet (centres and colours only: scale, "
            "opacity and anisotropy are lost) because X3D 4.0 has no GaussianSplats node; set Export > X3D Version to "
            "'X3D 4.1 draft (GaussianSplats)' to write the GaussianSplats node."
        )

    write = file.write
    output_dir = None
    output_name = getattr(file, "name", None)
    if output_name and not str(output_name).startswith("<"):
        output_dir = os.path.dirname(os.path.abspath(output_name))

    write('<?xml version="1.0" encoding="UTF-8"?>\n')
    write(f'<!DOCTYPE X3D PUBLIC "ISO//Web3D//DTD X3D {version}//EN" "https://www.web3d.org/specifications/x3d-{version}.dtd">\n')
    write(
        f'<X3D version="{version}" profile="Immersive" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema-instance" '
        f'xsd:noNamespaceSchemaLocation="https://www.web3d.org/specifications/x3d-{version}.xsd">\n'
    )
    write("  <head>\n")
    for name, level in _components(ir_scene, version):
        write(f'    <component name="{name}" level="{level}" />\n')
    for name, content in head_meta(ir_scene.metadata, generator, diagnostics):
        write(_meta(name, content))
    write("  </head>\n")
    write("  <Scene>\n")

    defs = _DefNames()
    geometries = ir_scene.geometry_by_name()
    materials = ir_scene.material_by_name()
    # An imported scene gets the headlight its file had (a browser's headlight lights the same faces whether or not the
    # file has lights; X3D's default is on); a scene made in Blender has none when it has lights of its own.
    headlight = ir_scene.headlight if ir_scene.headlight is not None else not ir_scene.has_lights()
    write(
        f'    <NavigationInfo headlight="{"true" if headlight else "false"}" '
        "type='\"EXAMINE\" \"ANY\"' />\n"
    )
    if ir_scene.background is not None:
        write(_background_xml(ir_scene.background, "    "))
    elif ir_scene.background_color is not None:
        write(f'    <Background skyColor="{_fmt3(ir_scene.background_color)}" />\n')
    humanoids = {humanoid.name: humanoid for humanoid in ir_scene.humanoids}
    splats = ir_scene.splats_by_name()
    for instance in ir_scene.instances:
        write(_instance_xml(instance, geometries, materials, defs, "    ", output_dir=output_dir, humanoids=humanoids,
                            splats=splats, version=version, look=look, collections=ir_scene.collections))
    write(_animation_xml(ir_scene, defs, "    "))
    write(_interaction_xml(ir_scene, defs, "    "))

    write("  </Scene>\n")
    write("</X3D>\n")
    replaced = nonfinite_count() - nonfinite_before
    if replaced:
        logging.getLogger(__name__).warning(
            "%d NaN or infinite number(s) in the scene were written as 0 (X3D has no such literal)", replaced)
