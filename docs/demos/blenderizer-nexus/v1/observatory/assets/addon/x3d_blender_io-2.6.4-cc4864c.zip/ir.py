# SPDX-FileCopyrightText: 2026 HagopJay
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Intermediate representation (IR) shared by the X3D 4.0 export and import paths.

This module must stay free of ``bpy`` imports so that it can be unit-tested
outside Blender. Extractors turn Blender data into these dataclasses, emitters
turn them into X3D, parsers turn X3D into them, and populators turn them back
into Blender data.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class IRMetadata:
    creator: str | None = None
    title: str | None = None
    description: str | None = None
    keywords: str | None = None
    reference: str | None = None
    license: str | None = None
    filename: str | None = None
    # (name, content) of every head meta read from an imported file, in file order; names may repeat.
    entries: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class IRTransform:
    translation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_axis_angle: tuple[float, float, float, float] = (0.0, 0.0, 1.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)


@dataclass
class IRTextureTransform:
    translation: tuple[float, float] = (0.0, 0.0)
    rotation: float = 0.0
    scale: tuple[float, float] = (1.0, 1.0)
    texcoord_set: int = 0


@dataclass
class IRTextureRef:
    image_name: str | None = None
    filepath: str | None = None
    source: str = "FILE"
    colorspace: str | None = None
    extension: str | None = None
    transform: IRTextureTransform | None = None
    usage: str | None = None
    # Final URL written into the X3D file. Filled in by the export pipeline
    # after path-mode resolution (COPY / RELATIVE / STRIP); when None the
    # emitter falls back to ``filepath``.
    url: str | None = None


@dataclass
class IRMeshGeometry:
    """One IndexedFaceSet worth of mesh data.

    Vertices are already split so that ``coord``, ``normal``, ``tex_coord``
    and ``color`` are parallel arrays indexed by ``coord_index`` (X3D
    ``normalPerVertex`` / ``colorPerVertex`` true with shared indices).
    A Blender mesh with several material slots becomes several geometries,
    one per slot, with ``material_slot`` recording which.
    """

    name: str
    coord: list[tuple[float, float, float]] = field(default_factory=list)
    coord_index: list[int] = field(default_factory=list)
    solid: bool = True
    crease_angle: float | None = None
    normal: list[tuple[float, float, float]] = field(default_factory=list)
    tex_coord: list[tuple[float, float]] = field(default_factory=list)
    color: list[tuple[float, float, float, float]] = field(default_factory=list)
    material_slot: int = 0
    source_mesh: str | None = None
    # Original Blender vertex index for every split vertex (skinning needs it).
    orig_vertex_index: list[int] = field(default_factory=list)
    # When set, ``coord`` is empty and ``coord_index`` points into the named
    # humanoid's shared skinCoord Coordinate node.
    skin_coord_def: str | None = None
    # True for a line-only mesh (a Blender curve, or loose edges): ``coord_index``
    # then holds polylines ended by -1 and the emitter writes an IndexedLineSet.
    is_lines: bool = False
    # True for a mesh of vertices only (no faces or edges): ``coord`` only, written as a PointSet.
    is_points: bool = False
    # Shape-key animation, written as a CoordinateInterpolator routed into the Coordinate:
    # ``morph_keys`` are fractions of the cycle in [0, 1], ``morph_states`` holds one point list
    # per key, each parallel to ``coord``.
    morph_keys: list[float] = field(default_factory=list)
    morph_states: list[list[tuple[float, float, float]]] = field(default_factory=list)


@dataclass
class IRPBRMaterial:
    name: str
    base_color: tuple[float, float, float, float] = (0.8, 0.8, 0.8, 1.0)
    emissive_color: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 1.0)
    metallic: float | None = None
    roughness: float | None = None
    # Principled "Specular IOR Level" and "Specular Tint" (the dielectric specular the X3D import builds from a
    # Material's specularColor and shininess); the classic Material writer turns them back into those two fields.
    specular_level: float | None = None
    specular_tint: tuple[float, float, float] | None = None
    # 'classic' when the import made this material from a Material or TwoSidedMaterial (it is written as a Material again
    # unless the export option says otherwise), else None: it follows the scene's ``material_model``.
    model: str | None = None
    normal_scale: float | None = None
    occlusion_strength: float | None = None
    alpha_mode: str = "OPAQUE"
    alpha_cutoff: float | None = None
    double_sided: bool | None = None
    unlit: bool = False
    base_color_texture: IRTextureRef | None = None
    metallic_roughness_texture: IRTextureRef | None = None
    normal_texture: IRTextureRef | None = None
    occlusion_texture: IRTextureRef | None = None
    emissive_texture: IRTextureRef | None = None

    def texture_refs(self):
        """Yield (containerField, IRTextureRef) pairs for every assigned texture."""
        for container_field, texture_ref in (
            ("baseTexture", self.base_color_texture),
            ("metallicRoughnessTexture", self.metallic_roughness_texture),
            ("normalTexture", self.normal_texture),
            ("emissiveTexture", self.emissive_texture),
            ("occlusionTexture", self.occlusion_texture),
        ):
            if texture_ref is not None:
                yield container_field, texture_ref


@dataclass
class IRInlineAsset:
    url: str
    # Where the asset was found when it was imported (absolute); the export writes ``url`` relative to its own folder
    # from it, since the url as the file gave it is relative to the folder the file lived in.
    source_path: str | None = None
    asset_type: str = "x3d"
    transform: IRTransform = field(default_factory=IRTransform)
    import_policy: str = "native"
    # the Inline's url MFString in order: alternatives for one asset, of which the first that loads is used (X3D 4.0
    # Networking); empty means just ``url``
    alternatives: tuple[str, ...] = ()

    def candidate_urls(self) -> tuple[str, ...]:
        return self.alternatives or (self.url,)


@dataclass
class IRGaussianSplats:
    """One X3D 4.1 GaussianSplats node worth of data (or a PointSet fallback in 4.0).

    ``orientations`` are unit quaternions as (x, y, z, w). ``scales`` are
    linear (not log) per-axis extents, ``opacities`` are 0..1 (not logits).
    ``sh`` maps (degree, coefficient) to a per-splat list of RGB coefficients;
    (0, 0) is the DC term the reconstructed colour comes from.
    """

    name: str
    positions: list[tuple[float, float, float]] = field(default_factory=list)
    scales: list[tuple[float, float, float]] = field(default_factory=list)
    orientations: list[tuple[float, float, float, float]] = field(default_factory=list)
    opacities: list[float] = field(default_factory=list)
    sh: dict[tuple[int, int], list[tuple[float, float, float]]] = field(default_factory=dict)
    color_space: str = "SRGB_REC709_DISPLAY"
    # Set by the extractor when the object asks (x3d_splat_glb) to be written as a KHR_gaussian_splatting glb beside the
    # X3D file and referenced by Inline: the file name, and the data is then already in glTF's Y-up frame, degree 0 only.
    glb_name: str | None = None

    def sh_degree(self) -> int:
        """Highest spherical-harmonic degree present in full, with every lower degree.

        A degree counts only when all 2d+1 coefficients are there: the draft
        node, KHR_gaussian_splatting and X_ITE all treat a partial degree as
        absent, so writers drop it rather than emit half of one. -1 = no DC.
        """
        complete = -1
        for degree in range(4):
            if not all(self.sh.get((degree, coef)) for coef in range(2 * degree + 1)):
                break
            complete = degree
        return complete

    def __len__(self) -> int:
        return len(self.positions)


@dataclass
class IRViewpoint:
    description: str | None = None
    transform: IRTransform = field(default_factory=IRTransform)
    field_of_view: float | None = None
    name: str | None = None
    # X3D 4.0 Viewpoint nearDistance and farDistance (the camera's clip range), written only when the camera's range is
    # not Blender's default 0.1 to 1000: a planet-scale view clips everything without them.
    near_distance: float | None = None
    far_distance: float | None = None


@dataclass
class IRMetadataNode:
    """One X3D Metadata* node. MetadataSet holds ``members``; the others hold ``value``, the field's X3D text."""

    node_type: str  # MetadataBoolean, MetadataDouble, MetadataFloat, MetadataInteger, MetadataSet, MetadataString
    name: str | None = None
    reference: str | None = None
    value: str | None = None
    members: list["IRMetadataNode"] = field(default_factory=list)


@dataclass
class IRLight:
    """A light written inside its owning Transform (location 0, direction -Z)."""

    name: str
    light_type: str = "POINT"  # POINT, SPOT, DIRECTIONAL
    color: tuple[float, float, float] = (1.0, 1.0, 1.0)
    intensity: float = 1.0
    ambient_intensity: float = 0.0
    radius: float | None = None
    beam_width: float | None = None
    cut_off_angle: float | None = None
    # X3D attenuation (a0 a1 a2) of a point or spot light, written only when an import kept it.
    attenuation: tuple[float, float, float] | None = None
    location: tuple[float, float, float] = (0.0, 0.0, 0.0)
    direction: tuple[float, float, float] = (0.0, 0.0, -1.0)
    # X3D 4.0 shadows (default FALSE); shadowIntensity (default 1) is written only when set.
    shadows: bool = False
    shadow_intensity: float | None = None
    # True when the light the file had was not global and lit nothing (no geometry in its scope): it is written with
    # global="false" again, so it lights nothing in a browser either. Every other light is written global="true".
    scoped: bool = False


@dataclass
class IRBackground:
    """An X3D Background gradient: N sky (ground) angles go with N + 1 sky (ground) colours."""

    sky_color: list[tuple[float, float, float]] = field(default_factory=lambda: [(0.0, 0.0, 0.0)])
    sky_angle: list[float] = field(default_factory=list)
    ground_color: list[tuple[float, float, float]] = field(default_factory=list)
    ground_angle: list[float] = field(default_factory=list)
    transparency: float = 0.0


@dataclass
class IRAnimation:
    """Sampled transform animation for one instance.

    ``keys`` are fractions of the cycle in [0, 1]; the value lists are
    parallel to ``keys``. Empty value lists mean that channel is static.
    """

    target: str
    target_kind: str = "transform"  # "transform" (OB_ DEF) or "joint" (HAnimJoint DEF)
    keys: list[float] = field(default_factory=list)
    translations: list[tuple[float, float, float]] = field(default_factory=list)
    rotations: list[tuple[float, float, float, float]] = field(default_factory=list)
    scales: list[tuple[float, float, float]] = field(default_factory=list)


@dataclass
class IRInteraction:
    """One authored ROUTE interaction: a sensor on ``source`` that fires an ``action``.

    ``trigger`` is ``click`` (TouchSensor) or ``proximity`` (ProximitySensor around the object's origin, ``radius`` m).
    ``action`` is ``animate`` (play ``target``'s sampled animation once), ``viewpoint`` (bind the camera ``target``) or
    ``tour`` (start the camera tour). Authored from the ``x3d_trigger`` / ``x3d_action`` / ``x3d_target`` /
    ``x3d_radius`` custom properties (source/interaction.py).
    """

    source: str
    trigger: str = "click"
    action: str = "animate"
    target: str = ""
    radius: float = 3.0


@dataclass
class IRTourStop:
    """One camera of a viewpoint tour, in the exported frame: where the tour rig rests and for how long."""

    name: str
    transform: IRTransform = field(default_factory=IRTransform)
    dwell: float = 2.0
    field_of_view: float | None = None


@dataclass
class IRTour:
    """A viewpoint tour: a Viewpoint carried by a Transform that PositionInterpolator / OrientationInterpolator fly
    through ``stops`` (``dwell`` seconds at each, ``travel`` seconds between). Started by a click or proximity
    interaction with action ``tour``, or by itself when ``autostart``."""

    stops: list[IRTourStop] = field(default_factory=list)
    travel: float = 3.0
    loop: bool = False
    autostart: bool = False


@dataclass
class IRShape:
    """One Shape inside an instance: a geometry paired with a material."""

    geometry_name: str | None = None
    material_name: str | None = None
    geometry_hint: str = "Sphere"
    # An imported Box, Sphere, Cylinder or Cone written back as that node: {"node": ..., "fields": {...}}
    # (extract.primitive_for_mesh); used instead of geometry_name.
    primitive: dict | None = None


@dataclass
class IRInstance:
    source_key: str
    object_name: str
    object_type: str = "EMPTY"
    geometry_hint: str = "Sphere"
    geometry_name: str | None = None
    material_name: str | None = None
    transform: IRTransform = field(default_factory=IRTransform)
    shapes: list[IRShape] = field(default_factory=list)
    children: list["IRInstance"] = field(default_factory=list)
    light: IRLight | None = None
    viewpoint: IRViewpoint | None = None
    humanoid_name: str | None = None
    # Set when the instance stands for an external asset referenced by Inline.
    inline: IRInlineAsset | None = None
    # Name of an IRGaussianSplats in IRScene.splats carried by this instance.
    splats_name: str | None = None
    # Shape castShadow (X3D 4.0, default TRUE): Blender's object shadow visibility.
    cast_shadow: bool = True
    # Metadata node written as the metadata field of the instance's first Shape.
    metadata: IRMetadataNode | None = None
    # Set by the extractor when a mesh-like object evaluated to no faces (edge-only mesh, zero vertices, Geometry
    # Nodes output that is only instances). Such an object keeps its Transform but must not get a placeholder Shape.
    no_faces: bool = False
    # False for an object the import hid for a Switch (its other choices): the Transform gets visible="false" (X3D 4.0)
    # when the whole subtree is hidden, otherwise only the object's own Shapes do, so the content survives the export
    # without being drawn and a visible child is not hidden with its parent.
    visible: bool = True
    # LineProperties linewidthScaleFactor of the instance's line geometry, kept by the import; written as a LineProperties.
    line_width: float | None = None
    # Name of an IRScene.collections entry this Empty instances (Blender "Collection" instance); written as a Group that
    # is DEF'd at its first use and USE'd after, so N linked copies cost N Transforms, not N copies of the content.
    collection_name: str | None = None
    # The ROUTE interaction authored on this object (a sensor inside its Transform), if any.
    interaction: IRInteraction | None = None

    def iter_shapes(self):
        """Yield the shapes of this instance.

        Instances built before multi-material support carry a single
        ``geometry_name`` / ``material_name`` pair; those are still honoured.
        """
        if self.shapes:
            yield from self.shapes
        elif self.inline is not None or self.splats_name or self.no_faces:
            return
        elif self.geometry_name or self.material_name or self.object_type == "MESH":
            yield IRShape(
                geometry_name=self.geometry_name,
                material_name=self.material_name,
                geometry_hint=self.geometry_hint,
            )


@dataclass
class IRJoint:
    """One HAnimJoint: a Blender bone. ``center`` is the bone head in humanoid space."""

    name: str
    center: tuple[float, float, float] = (0.0, 0.0, 0.0)
    # The H-Anim 2.0 standard joint name this bone is written under (hanim_names.py), else None: ``name`` is then written.
    # ``name`` stays the Blender bone name: it keys the DEF, the vertex group and the animation target.
    hanim_name: str | None = None
    children: list["IRJoint"] = field(default_factory=list)
    skin_coord_index: list[int] = field(default_factory=list)
    skin_coord_weight: list[float] = field(default_factory=list)

    def iter_joints(self):
        yield self
        for child in self.children:
            yield from child.iter_joints()


@dataclass
class IRHumanoid:
    """An HAnimHumanoid built from one armature and the meshes it deforms."""

    name: str
    transform: IRTransform = field(default_factory=IRTransform)
    root_joints: list[IRJoint] = field(default_factory=list)
    skin_coord: list[tuple[float, float, float]] = field(default_factory=list)
    skin_shapes: list[IRShape] = field(default_factory=list)
    # Joints written under a standard H-Anim name, and the total (the HAnimHumanoid ``info`` says so).
    standard_joint_count: int = 0

    def iter_joints(self):
        for root in self.root_joints:
            yield from root.iter_joints()


@dataclass
class IRScene:
    name: str
    source_version: str = "blender"
    source_path: str | None = None
    metadata: IRMetadata = field(default_factory=IRMetadata)
    object_names: list[str] = field(default_factory=list)
    geometries: list[IRMeshGeometry] = field(default_factory=list)
    materials: list[IRPBRMaterial] = field(default_factory=list)
    instances: list[IRInstance] = field(default_factory=list)
    inline_assets: list[IRInlineAsset] = field(default_factory=list)
    viewpoints: list[IRViewpoint] = field(default_factory=list)
    navigation_types: list[str] = field(default_factory=list)
    diagnostics: list[str] = field(default_factory=list)
    animations: list[IRAnimation] = field(default_factory=list)
    humanoids: list[IRHumanoid] = field(default_factory=list)
    splats: list[IRGaussianSplats] = field(default_factory=list)
    cycle_interval: float | None = None
    tour: IRTour | None = None
    # Collection name -> its member instances in the collection's own frame (instance_offset at the origin).
    collections: dict[str, list[IRInstance]] = field(default_factory=dict)
    background_color: tuple[float, float, float] | None = None
    # A Background read by the importer; written instead of ``background_color`` (the world's colour) when set.
    background: IRBackground | None = None
    # How the exported materials are lit: 'classic' (X3D Material, Phong; X_ITE shades it in display space) or
    # 'physical' (PhysicalMaterial, glTF style). Taken from the scene's x3d_lighting_model unless the export option sets it.
    material_model: str = "physical"
    # True when the export option chose the model (every material then follows it, whatever it was imported as).
    material_model_forced: bool = False
    # The NavigationInfo headlight the scene had when it was imported (True/False), None when it never had one.
    headlight: bool | None = None

    def iter_instances(self):
        """Depth-first walk over every instance, nested children included (the members of each instanced collection
        included, once, however many times it is instanced)."""
        stack = list(reversed(self.instances))
        for members in reversed(list(self.collections.values())):
            stack = list(reversed(members)) + stack
        while stack:
            instance = stack.pop()
            yield instance
            stack.extend(reversed(instance.children))

    def splats_by_name(self) -> dict[str, IRGaussianSplats]:
        return {splats.name: splats for splats in self.splats}

    def has_lights(self) -> bool:
        return any(instance.light is not None for instance in self.iter_instances())

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def geometry_by_name(self) -> dict[str, IRMeshGeometry]:
        return {geometry.name: geometry for geometry in self.geometries}

    def material_by_name(self) -> dict[str, IRPBRMaterial]:
        return {material.name: material for material in self.materials}

    def iter_texture_refs(self):
        for material in self.materials:
            for _container_field, texture_ref in material.texture_refs():
                yield texture_ref
