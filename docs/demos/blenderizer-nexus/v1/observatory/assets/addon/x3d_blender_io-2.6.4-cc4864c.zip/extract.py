# SPDX-FileCopyrightText: 2026 HagopJay
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Blender scene -> IR extraction for the X3D 4.0 export path.

Everything that touches ``bpy`` data on the export side lives here. The
emitter (``emit_x3d40``) never sees Blender objects.
"""

from __future__ import annotations

import math
import os

try:
    from .ir import IRAnimation, IRHumanoid, IRInstance, IRJoint, IRLight, IRMeshGeometry, IRMetadata, IRMetadataNode, IRBackground, IRScene, IRShape, IRTransform, IRViewpoint, IRGaussianSplats, IRInlineAsset
    from .hanim_names import HANIM_JOINT_PROPERTY, HANIM_NAMES_PROPERTY, map_bones
    from .interaction import check_interactions, read_interaction, read_tour
    from .material import analyze_material
    from .matrix_safety import axis_scales, inverted64, scale_to_children_matrix
    from .splat_io import rgb_to_sh0
    from .splat_native import extract_native_splats, is_native_splat_object
    from .viewpoint_fov import render_size, x3d_field_of_view
except ImportError:  # pragma: no cover - standalone test fallback
    from ir import IRAnimation, IRHumanoid, IRInstance, IRJoint, IRLight, IRMeshGeometry, IRMetadata, IRMetadataNode, IRBackground, IRScene, IRShape, IRTransform, IRViewpoint, IRGaussianSplats, IRInlineAsset
    from hanim_names import HANIM_JOINT_PROPERTY, HANIM_NAMES_PROPERTY, map_bones
    from interaction import check_interactions, read_interaction, read_tour
    from material import analyze_material
    from matrix_safety import axis_scales, inverted64, scale_to_children_matrix
    from splat_io import rgb_to_sh0
    from splat_native import extract_native_splats, is_native_splat_object
    from viewpoint_fov import render_size, x3d_field_of_view


MESH_LIKE_TYPES = {"MESH", "CURVE", "SURFACE", "FONT"}

# Custom properties and point attributes that mark a mesh as Gaussian splats.
SPLAT_PROPERTY = "x3d_gaussian_splats"
SPLAT_COLOR_SPACE_PROPERTY = "x3d_splat_color_space"
SPLAT_SCALE_ATTR = "splat_scale"
SPLAT_ROTATION_ATTR = "splat_rotation"
SPLAT_OPACITY_ATTR = "splat_opacity"
SPLAT_SH_ATTR = "splat_sh{degree}_{coef}"
# A mesh's X3D ``solid`` as the file gave it (the import leaves a classic Material's surface two-sided in Blender, so the
# material's backface-culling flag cannot tell the export).
SOLID_PROPERTY = "x3d_solid"
# A line set's LineProperties linewidthScaleFactor, kept on the object by the importer (Blender draws no line width).
LINE_WIDTH_PROPERTY = "x3d_line_width"
INLINE_URL_PROPERTY = "x3d_inline_url"
INLINE_SOURCE_PROPERTY = "x3d_inline_source"
# Where each Inline asset was found at import: the placeholder empty's ``session_uid`` -> absolute path. Kept in this
# session only (an absolute path in a custom property would travel into a glb's extras and .blend files and name the
# importing machine's folders; the portable x3d_inline_resolved_path is relative to the importing file), so the
# export can write the Inline's url relative to its own folder (export_pipeline.resolve_inline_urls). The value is the
# url the empty got at import together with the path, so a url edited afterwards is not overridden by the old location.
INLINE_SOURCE_PATHS: dict[int, tuple[str, str]] = {}
# The same paths by the url they were found for: a duplicated placeholder has no entry of its own and takes the path its
# url was imported with, when that is unambiguous.
INLINE_SOURCE_BY_URL: dict[str, set[str]] = {}


def record_inline_source(uid, url, path):
    """Remember where the Inline ``url`` of the placeholder with session id ``uid`` was found at import."""
    INLINE_SOURCE_PATHS[uid] = (url, path)
    INLINE_SOURCE_BY_URL.setdefault(url, set()).add(path)


def inline_source_path(uid, url):
    """The absolute path the import found for ``url``: the placeholder's own record while its url is unchanged, for a
    placeholder with no record (a duplicate) the single path any import found for that url, else None."""
    record = INLINE_SOURCE_PATHS.get(uid)
    if record is not None:
        return record[1] if record[0] == url else None
    paths = INLINE_SOURCE_BY_URL.get(url)
    return next(iter(paths)) if paths and len(paths) == 1 else None
# X3D light fields with no Blender setting, kept on the light data by the importer.
LIGHT_AMBIENT_INTENSITY_PROPERTY = "x3d_ambient_intensity"
LIGHT_SHADOW_INTENSITY_PROPERTY = "x3d_shadow_intensity"
# A light's X3D ``global`` field as the file gave it (X3D's default: TRUE for point and spot lights, FALSE for directional
# ones), and, for a light that is not global, whether any geometry sat in its scope (its parent's other children). Blender
# lights light the whole scene and the export puts each light in a Transform of its own, so a scoped light that lit
# geometry in the file is written global, and one that lit nothing keeps global="false".
LIGHT_GLOBAL_PROPERTY = "x3d_global"
LIGHT_SCOPE_LIT_PROPERTY = "x3d_scope_lit"
# The intensity a light had in the X3D file it was imported from; it also marks the light as imported.
LIGHT_INTENSITY_PROPERTY = "x3d_intensity"
# Blender energy per unit of X3D intensity, set by an import in X_ITE light units (see import_x3d.LIGHT_UNITS);
# without it, point and spot lights use 1.75 W per unit and sun lights 1.
LIGHT_ENERGY_PER_INTENSITY_PROPERTY = "x3d_energy_per_intensity"
# A point or spot light's X3D attenuation (a0 a1 a2), kept when the file sets it so the export writes it back.
LIGHT_ATTENUATION_PROPERTY = "x3d_attenuation"
# The distance an X_ITE-units import matched a point or spot light at (metres, see import_x3d.reference_distance).
LIGHT_REFERENCE_DISTANCE_PROPERTY = "x3d_reference_distance"
# A point or spot light's X3D radius as the file set it (in Blender units of the light's own frame; -1 is unlimited),
# so the exports write it back: Blender's cutoff distance holds the world-space range, which also scales with the
# light's Transforms and is unset for a radius of -1 or 0.
LIGHT_RADIUS_PROPERTY = "x3d_radius"
# A light's X3D color as the file gave it, kept when the import made the Blender colour linear (a classic scene read
# as sRGB, the way X_ITE lights classic Materials), so the X3D 3.3 export can write the file's value back.
LIGHT_COLOR_PROPERTY = "x3d_color"
# The import's colour space (AS_IS or SRGB) on the scene, so the export can write colours back the same way.
COLOUR_SPACE_PROPERTY = "x3d_color_space"
COLOUR_SPACES = ('AS_IS', 'SRGB')
# How the import lit the scene (classic Phong Materials, or glTF-style PhysicalMaterials), kept on the scene; and the
# first NavigationInfo's headlight (True when the file had no NavigationInfo), so the export writes them back.
LIGHTING_MODEL_PROPERTY = "x3d_lighting_model"
HEADLIGHT_PROPERTY = "x3d_headlight"
MATERIAL_MODELS = ('classic', 'physical')
# On a material the import made from a classic Material or TwoSidedMaterial, so the export can write one back in a scene
# whose lights were fitted for PhysicalMaterials (a file that mixes both).
MATERIAL_MODEL_PROPERTY = "x3d_material_model"


def linear_to_srgb(value):
    """One linear channel in sRGB encoding (the inverse of the import's srgb_to_linear)."""
    value = max(0.0, float(value))
    return value * 12.92 if value <= 0.0031308 else 1.055 * value ** (1.0 / 2.4) - 0.055


def display_colour(rgb, colour_space):
    """A Blender (linear) colour as a classic X3D colour field holds it: sRGB-encoded under 'SRGB', the way X_ITE and
    Castle read Material, TwoSidedMaterial, UnlitMaterial and Color, or unchanged under 'AS_IS'."""
    rgb = tuple(float(c) for c in rgb)
    if colour_space != 'SRGB':
        return rgb
    return tuple(linear_to_srgb(c) for c in rgb)


def resolve_export_colour_space(value=None, scene=None, default='SRGB'):
    """The export option when given (not AUTO); else the colour space the scene was imported with
    (COLOUR_SPACE_PROPERTY); else the BLENDER_X3D_COLOR_SPACE environment variable; else `default`, 'SRGB': a scene
    made in Blender holds linear colours, and X_ITE and Castle read classic and unlit colours as sRGB values."""
    aliases = {"X_ITE": "SRGB", "XITE": "SRGB", "LINEAR": "AS_IS", "NONE": "AS_IS", "AUTO": ""}
    raw = str(value or "").strip().upper()
    raw = aliases.get(raw, raw)
    if not raw and scene is not None:
        try:
            recorded = imported_scene_property(scene, COLOUR_SPACE_PROPERTY)
        except (AttributeError, TypeError):
            recorded = None
        raw = aliases.get(str(recorded or "").strip().upper(), str(recorded or "").strip().upper())
    if not raw:
        env = os.environ.get("BLENDER_X3D_COLOR_SPACE", "").strip().upper()
        raw = aliases.get(env, env)
    return raw if raw in COLOUR_SPACES else default
# Viewpoint description read by the importer, kept on the camera object.
VIEWPOINT_DESCRIPTION_PROPERTY = "x3d_viewpoint_description"
# Head meta statements read by the importer, kept on the scene as a list of {"name", "content"}.
IMPORTED_ANIMATION_PROPERTY = "x3d_imported_animation"   # set on the scene when an X3D import made animation (interpolators, TimeSensors)
SWITCH_HIDDEN_PROPERTY = "x3d_switch_hidden"   # set by the importer on the objects of a Switch choice that is not shown (and on their descendants)
LOD_HIDDEN_PROPERTY = "x3d_lod_hidden"   # set by the importer on the objects of an LOD level the first Viewpoint does not see
HEAD_META_PROPERTY = "x3d_head_meta"
# A Shape's Metadata* node read by the importer, kept on the object as nested {"node", "name", "reference", "value"}.
METADATA_PROPERTY = "x3d_metadata"
METADATA_NODE_TYPES = frozenset(
    ("MetadataBoolean", "MetadataDouble", "MetadataFloat", "MetadataInteger", "MetadataSet", "MetadataString"))
# The first Background of an imported file, kept on the scene: skyColor, skyAngle, groundColor, groundAngle
# (flat lists of numbers) and transparency.
BACKGROUND_PROPERTY = "x3d_background"
# The headlight level an import in classic light units matched (a rig and diagnostics value; the export does not read it).
HEADLIGHT_LUX_PROPERTY = "x3d_headlight_lux"
# Set by the importer on every object it makes. The scene-level properties below describe what an import brought in, so
# they stop applying when none of that content is left in the scene (scene_has_imported_content).
IMPORTED_OBJECT_PROPERTY = "x3d_imported"
SCENE_IMPORT_PROPERTIES = (COLOUR_SPACE_PROPERTY, LIGHTING_MODEL_PROPERTY, HEADLIGHT_PROPERTY, HEADLIGHT_LUX_PROPERTY,
                           IMPORTED_ANIMATION_PROPERTY, HEAD_META_PROPERTY, BACKGROUND_PROPERTY)
# What marks content of a file imported before IMPORTED_OBJECT_PROPERTY existed: a DEF, USE or Inline record on the
# object, a primitive, solid, light or splat record on its data (the importer's own names; extract cannot import them).
_IMPORTED_OBJECT_MARKS = (IMPORTED_OBJECT_PROPERTY, "x3d_def", "x3d_def_path", "x3d_use", INLINE_URL_PROPERTY)
_IMPORTED_DATA_MARKS = ("x3d_def", SOLID_PROPERTY, "x3d_primitive", LIGHT_INTENSITY_PROPERTY, SPLAT_PROPERTY)


def is_imported_object(obj) -> bool:
    """True for an object the X3D import made (see IMPORTED_OBJECT_PROPERTY and the older marks above)."""
    try:
        if any(key in obj for key in _IMPORTED_OBJECT_MARKS):
            return True
        data = getattr(obj, "data", None)
        return data is not None and any(key in data for key in _IMPORTED_DATA_MARKS)
    except (TypeError, ReferenceError):
        return False


def scene_has_imported_content(scene) -> bool:
    """True while ``scene`` still holds an object an X3D import made. A stand-in without ``objects`` (not a Blender
    scene) counts as holding some: there is nothing to check, so its properties are trusted."""
    objects = getattr(scene, "objects", None)
    if objects is None:
        return True
    return any(is_imported_object(obj) for obj in objects)


def imported_scene_property(scene, key):
    """The value the import kept on ``scene`` under ``key``, or None when it was never set or the scene no longer holds
    imported content: the flags are the file's (its headlight, its lighting model, its Background), and once the imported
    objects are gone the scene is a Blender scene again, whatever it was imported from."""
    try:
        value = scene.get(key)
    except (AttributeError, TypeError):
        return None
    if value is None or not scene_has_imported_content(scene):
        return None
    return value


def clear_stale_scene_properties(scene) -> bool:
    """Drop the scene-level import properties when the scene holds no imported content, so the next import starts from
    a clean scene (a file without a Background or animation must not inherit an earlier file's). True if any were."""
    if scene is None or scene_has_imported_content(scene):
        return False
    cleared = False
    for key in SCENE_IMPORT_PROPERTIES:
        try:
            if key in scene:
                del scene[key]
                cleared = True
        except (TypeError, KeyError, ReferenceError):
            continue
    return cleared


def _line_width(obj):
    """The LineProperties linewidthScaleFactor the import kept on a line object, else None."""
    try:
        width = float(obj.get(LINE_WIDTH_PROPERTY))
    except (AttributeError, TypeError, ValueError):
        return None
    return width if math.isfinite(width) and width >= 0.0 else None


def _session_uid(obj):
    try:
        return int(obj.session_uid)
    except (AttributeError, TypeError, ValueError, ReferenceError):
        return None


def resolve_material_model(value=None, scene=None, default='physical'):
    """'classic' (write X3D Materials: Phong, diffuse, specular, shininess) or 'physical' (PhysicalMaterial, glTF style).

    The export option when given (not AUTO); else the lighting model the scene was imported with
    (LIGHTING_MODEL_PROPERTY): a file lit by Materials stays lit by Materials, which X_ITE shades in display space and
    far brighter than a PhysicalMaterial of the same colour (measured: a 0.8 grey box lit by a point light draws 204
    with a Material and 130 with the PhysicalMaterial the export used to write); else `default`, 'physical': a scene
    made in Blender is a Principled BSDF scene, which is PBR."""
    raw = str(value or "").strip().lower()
    if raw in ("auto", "none"):
        raw = ""
    if not raw and scene is not None:
        try:
            raw = str(imported_scene_property(scene, LIGHTING_MODEL_PROPERTY) or "").strip().lower()
        except (AttributeError, TypeError):
            raw = ""
    return raw if raw in MATERIAL_MODELS else default


def scene_headlight(scene):
    """The headlight the import recorded for the scene (True or False), None for a scene that was not imported or no
    longer holds what was."""
    recorded = imported_scene_property(scene, HEADLIGHT_PROPERTY)
    if recorded is None:
        return None
    return bool(recorded)


def is_splat_mesh(obj) -> bool:
    data = getattr(obj, "data", None)
    return obj.type == "MESH" and data is not None and bool(data.get(SPLAT_PROPERTY))


def inline_root(obj):
    """The Inline placeholder empty this object was imported under, or None."""
    if obj.get(INLINE_SOURCE_PROPERTY) is None:
        return None
    parent = obj.parent
    while parent is not None:
        if parent.get(INLINE_URL_PROPERTY):
            return parent
        parent = parent.parent
    return None


def asset_frame(global_matrix):
    """Rotation taking a Y-up asset (glTF, X3D, splat file) into Blender's Z-up frame.

    Content under an Inline placeholder empty is laid out the way Blender's own
    importers would place it; the Inline's Transform therefore carries this
    extra rotation so the X3D browser sees the asset in its native frame.
    """
    from mathutils import Matrix

    if global_matrix is None:
        return Matrix.Identity(4)
    rotation = global_matrix.to_3x3()
    rotation.normalize()
    return rotation.inverted().to_4x4()


SPLAT_GLB_PROPERTY = "x3d_splat_glb"


def splats_to_gltf_frame(splats, global_matrix):
    """Turn a splat set into glTF's Y-up frame in place (what ``Inline`` of a glb expects), degree 0 only.

    Centres and orientations are rotated by the export's axis conversion; scales stay (they are per local axis); spherical
    harmonics above degree 0 are dropped, since they depend on the view direction and would have to be rotated too.
    Returns True when higher degrees were dropped.
    """
    from mathutils import Quaternion, Vector

    rotation = global_matrix.to_3x3() if global_matrix is not None else None
    if rotation is not None:
        rotation = rotation.copy()
        rotation.normalize()
        turn = rotation.to_quaternion()
        splats.positions = [tuple(rotation @ Vector(point)) for point in splats.positions]
        turned = []
        for x, y, z, w in splats.orientations:
            q = turn @ Quaternion((w, x, y, z))
            turned.append((q.x, q.y, q.z, q.w))
        splats.orientations = turned
    dropped = any(degree > 0 for degree, _coef in splats.sh)
    splats.sh = {key: value for key, value in splats.sh.items() if key == (0, 0)}
    return dropped


def extract_splats(mesh, *, name: str) -> IRGaussianSplats:
    """Read a splat mesh (vertices plus splat_* point attributes) into IRGaussianSplats."""
    splats = IRGaussianSplats(name=name, color_space=str(mesh.get(SPLAT_COLOR_SPACE_PROPERTY, "SRGB_REC709_DISPLAY")))
    count = len(mesh.vertices)
    # unrounded: the emitter writes float32-exact text for splat arrays
    splats.positions = [tuple(vertex.co) for vertex in mesh.vertices]
    attributes = mesh.attributes

    def vectors(attr_name, width):
        attr = attributes.get(attr_name)
        if attr is None or attr.domain != "POINT" or len(attr.data) != count:
            return None
        key = "vector" if attr.data_type == "FLOAT_VECTOR" else "color" if attr.data_type == "FLOAT_COLOR" else "value"
        return [tuple(float(c) for c in getattr(item, key)[:width]) for item in attr.data]

    scales = vectors(SPLAT_SCALE_ATTR, 3)
    splats.scales = scales if scales else [(0.01, 0.01, 0.01)] * count
    rotation = attributes.get(SPLAT_ROTATION_ATTR)
    if rotation is not None and rotation.domain == "POINT" and len(rotation.data) == count:
        if rotation.data_type == "QUATERNION":
            # Blender quaternions are (w, x, y, z); the IR and X3D carry (x, y, z, w)
            splats.orientations = [(q.value[1], q.value[2], q.value[3], q.value[0]) for q in rotation.data]
        elif rotation.data_type == "FLOAT_COLOR":
            splats.orientations = [tuple(float(c) for c in q.color[:4]) for q in rotation.data]
    if not splats.orientations:
        splats.orientations = [(0.0, 0.0, 0.0, 1.0)] * count
    opacity = attributes.get(SPLAT_OPACITY_ATTR)
    if opacity is not None and opacity.domain == "POINT" and len(opacity.data) == count:
        splats.opacities = [max(0.0, min(1.0, float(item.value))) for item in opacity.data]
    else:
        splats.opacities = [1.0] * count
    dc = vectors(SPLAT_SH_ATTR.format(degree=0, coef=0), 3)
    if dc is None:
        color_attr = attributes.get("Color") or getattr(mesh, "color_attributes", None) and mesh.color_attributes.active_color
        if color_attr is not None and color_attr.domain == "POINT" and len(color_attr.data) == count:
            dc = [rgb_to_sh0(tuple(float(c) for c in item.color[:3])) for item in color_attr.data]
    if dc:
        splats.sh[(0, 0)] = dc
    for degree in (1, 2, 3):
        for coef in range(2 * degree + 1):
            values = vectors(SPLAT_SH_ATTR.format(degree=degree, coef=coef), 3)
            if values is None:
                break
            splats.sh[(degree, coef)] = values
    return splats


_ROUND = 6


def _read_all(collection, prop, width):
    """Every ``prop`` of a Blender collection as a list of tuples, from one ``foreach_get``.

    Returns ``None`` when Blender refuses the bulk read. Reading a corner attribute one element at a time
    (``collection[i].prop``) costs time proportional to the collection's size in Blender 5.x, which made the
    export quadratic: a 66k-vertex grid took five minutes. One bulk read is linear.
    """
    count = len(collection)
    flat = [0.0] * (count * width)
    try:
        collection.foreach_get(prop, flat)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None
    return [tuple(flat[i : i + width]) for i in range(0, count * width, width)]


def _tuple_accessor(collection, prop, keep):
    """Return ``index -> tuple(collection[index].prop[:keep])``.

    The whole collection is read once when Blender allows it, element by element otherwise.
    """
    if len(collection):
        values = _read_all(collection, prop, len(getattr(collection[0], prop)))
        if values is not None:
            return lambda index: values[index][:keep]
    return lambda index: tuple(getattr(collection[index], prop)[:keep])


def _uv_values(mesh):
    """Return a per-loop UV accessor for the active UV layer, or None."""
    uv_layers = getattr(mesh, "uv_layers", None)
    layer = uv_layers.active if uv_layers else None
    if layer is None:
        return None
    uv_attr = getattr(layer, "uv", None)
    if uv_attr is not None and len(uv_attr) == len(mesh.loops):
        return _tuple_accessor(uv_attr, "vector", 2)
    data = getattr(layer, "data", None)
    if data is not None:
        return _tuple_accessor(data, "uv", 2)
    return None


def _corner_normals(mesh):
    """Return a per-loop normal accessor (Blender 4.1+ ``corner_normals``)."""
    corner_normals = getattr(mesh, "corner_normals", None)
    if corner_normals is not None and len(corner_normals) == len(mesh.loops):
        return _tuple_accessor(corner_normals, "vector", 3)
    return _tuple_accessor(mesh.loops, "normal", 3)


def _color_values(mesh):
    """Return (accessor, domain) for the active color attribute, or (None, None)."""
    attributes = getattr(mesh, "color_attributes", None)
    if not attributes:
        return None, None
    attr = getattr(attributes, "active_color", None)
    if attr is None:
        return None, None
    data = attr.data
    domain = attr.domain  # 'POINT' or 'CORNER'
    colors = _read_all(data, "color", len(data[0].color)) if len(data) else None

    def accessor(index):
        color = colors[index] if colors is not None else data[index].color
        alpha = float(color[3]) if len(color) > 3 else 1.0
        return (float(color[0]), float(color[1]), float(color[2]), alpha)

    return accessor, domain


# Set by the import on a mesh it tessellated from a Box, Sphere, Cylinder or Cone (import_x3d.mark_primitive).
PRIMITIVE_PROPERTY = "x3d_primitive"
_PRIMITIVE_NODES = frozenset(("Box", "Sphere", "Cylinder", "Cone"))


def _position_signature(mesh):
    """import_x3d.position_signature: (vertex count, face count, weighted position sum)."""
    count = len(mesh.vertices)
    flat = [0.0] * (count * 3)
    mesh.vertices.foreach_get("co", flat)
    weighted = sum(value * (1 + (index % 7)) for index, value in enumerate(flat))
    return [count, len(mesh.polygons), round(weighted, 5)]


def primitive_for_mesh(mesh):
    """The X3D primitive an unedited imported mesh came from, as {"node": ..., "fields": {...}}, or None.

    None when the mesh has no record, when any vertex moved or the vertex or face count changed since the import,
    or when it gained what a primitive cannot carry (several materials, colour attributes, shape keys)."""
    import json
    try:
        raw = mesh.get(PRIMITIVE_PROPERTY)
    except (AttributeError, TypeError):
        return None
    if not raw:
        return None
    try:
        record = json.loads(raw)
    except (TypeError, ValueError):
        return None
    if record.get("node") not in _PRIMITIVE_NODES or not isinstance(record.get("fields"), dict):
        return None
    if getattr(mesh, "shape_keys", None) is not None or len(getattr(mesh, "color_attributes", ()) or ()) \
            or len([m for m in getattr(mesh, "materials", ()) if m is not None]) > 1:
        return None
    signature = record.get("signature")
    current = _position_signature(mesh)
    if not signature or len(signature) != 3 or signature[:2] != current[:2] \
            or abs(float(signature[2]) - current[2]) > 1e-4 * max(1.0, abs(current[2])):
        return None
    return {"node": record["node"], "fields": dict(record["fields"])}


def _edge_polylines(edges) -> list[list[int]]:
    """Chain mesh edges (pairs of vertex indices) into polylines, endpoints first."""
    adjacent: dict[int, list[int]] = {}
    for a, b in edges:
        adjacent.setdefault(a, []).append(b)
        adjacent.setdefault(b, []).append(a)
    unused = {tuple(sorted(e)) for e in edges}
    lines: list[list[int]] = []
    starts = [v for v, n in adjacent.items() if len(n) != 2] + sorted(adjacent)
    for start in starts:
        while any(tuple(sorted((start, n))) in unused for n in adjacent[start]):
            line, current = [start], start
            while True:
                step = next((n for n in adjacent[current] if tuple(sorted((current, n))) in unused), None)
                if step is None:
                    break
                unused.discard(tuple(sorted((current, step))))
                line.append(step)
                current = step
            lines.append(line)
    return lines


def _extract_edge_lines(mesh, *, name: str, vertex_matrix=None, edges=None) -> list[IRMeshGeometry]:
    """A mesh's loose edges (all of them for a mesh without faces: an evaluated curve) become one line geometry."""
    lines = _edge_polylines(edges if edges is not None else [tuple(edge.vertices) for edge in mesh.edges])
    if not lines:
        return []
    used = sorted({v for line in lines for v in line})
    remap = {old: new for new, old in enumerate(used)}
    coord = []
    for old in used:
        point = mesh.vertices[old].co
        if vertex_matrix is not None:
            point = vertex_matrix @ point
        coord.append((float(point[0]), float(point[1]), float(point[2])))
    coord_index: list[int] = []
    for line in lines:
        coord_index.extend(remap[v] for v in line)
        coord_index.append(-1)
    # a line set's colours (the import's POINT colour attribute, one per vertex) go back as a Color / ColorRGBA node
    color_at, color_domain = _color_values(mesh)
    color = [color_at(old) for old in used] if color_at is not None and color_domain == "POINT" else []
    return [IRMeshGeometry(name=name, coord=coord, coord_index=coord_index, source_mesh=name,
                           orig_vertex_index=used, is_lines=True, color=color)]



def _extract_loose_points(mesh, *, name: str, indices, vertex_matrix=None) -> list[IRMeshGeometry]:
    """Vertices no face or edge uses become one point geometry (a PointSet), with their POINT colours."""
    coord = []
    for index in indices:
        point = mesh.vertices[index].co
        if vertex_matrix is not None:
            point = vertex_matrix @ point
        coord.append((float(point[0]), float(point[1]), float(point[2])))
    color_at, color_domain = _color_values(mesh)
    color = [color_at(index) for index in indices] if color_at is not None and color_domain == "POINT" else []
    return [IRMeshGeometry(name=name, coord=coord, source_mesh=name, orig_vertex_index=list(indices), is_points=True,
                           color=color)]


def _extract_loose_geometries(mesh, *, name: str, vertex_matrix=None, alone: bool) -> list[IRMeshGeometry]:
    """Loose edges as lines, named ``name`` when they are all the mesh has; a mesh of vertices only as points.

    Stray vertices beside faces or edges stay unwritten (suite case Z01.loose.geometry: they must not inflate the
    object's bounds); a mesh that is nothing but vertices (a point cloud kept as a mesh) has nothing else to show."""
    vertices = getattr(mesh, "vertices", None)
    if vertices is None or not len(vertices):
        return []
    used = bytearray(len(vertices))
    loops = getattr(mesh, "loops", None)
    if getattr(mesh, "polygons", None) and loops is not None and len(loops):
        corner_vertices = [0] * len(loops)
        loops.foreach_get("vertex_index", corner_vertices)
        for index in corner_vertices:
            used[index] = 1
    loose_edges = []
    edges = getattr(mesh, "edges", None)
    if edges is not None and len(edges):
        loose = [False] * len(edges)
        edges.foreach_get("is_loose", loose)
        ends = [0] * (2 * len(edges))
        edges.foreach_get("vertices", ends)
        loose_edges = [(ends[2 * i], ends[2 * i + 1]) for i, flag in enumerate(loose) if flag]
        for a, b in loose_edges:
            used[a] = used[b] = 1
    if loose_edges:
        return _extract_edge_lines(mesh, name=name if alone else f"{name}_lines", vertex_matrix=vertex_matrix,
                                   edges=loose_edges)
    if alone and not any(used):
        return _extract_loose_points(mesh, name=name, indices=range(len(vertices)), vertex_matrix=vertex_matrix)
    return []


def _crease_from_sharp_edges(mesh) -> float:
    """``creaseAngle`` for a smooth-shaded mesh: just under the smallest dihedral angle among sharp edges.

    The importer turns ``creaseAngle`` into sharp edges, so this brings the angle back (a mesh with no sharp
    edge stays fully smooth, pi). Any failure falls back to pi.
    """

    try:
        import numpy as np

        edges, polys, loops = mesh.edges, mesh.polygons, mesh.loops
        sharp = np.zeros(len(edges), dtype=bool)
        edges.foreach_get("use_edge_sharp", sharp)
        if not sharp.any():
            return math.pi
        normals = np.zeros(len(polys) * 3, dtype=np.float32)
        polys.foreach_get("normal", normals)
        normals = normals.reshape(-1, 3)
        loop_edge = np.zeros(len(loops), dtype=np.int64)
        loops.foreach_get("edge_index", loop_edge)
        loop_poly = np.zeros(len(loops), dtype=np.int64)
        for polygon in polys:
            loop_poly[polygon.loop_start:polygon.loop_start + polygon.loop_total] = polygon.index
        first = np.full(len(edges), -1, dtype=np.int64)
        second = np.full(len(edges), -1, dtype=np.int64)
        for edge_index, poly_index in zip(loop_edge, loop_poly):
            if first[edge_index] < 0:
                first[edge_index] = poly_index
            elif second[edge_index] < 0:
                second[edge_index] = poly_index
        both = sharp & (first >= 0) & (second >= 0)
        if not both.any():
            return math.pi
        dots = np.einsum("ij,ij->i", normals[first[both]], normals[second[both]])
        angles = np.arccos(np.clip(dots, -1.0, 1.0))
        return float(angles.min()) * 0.999
    except Exception:
        return math.pi

def extract_mesh_geometries(
    mesh,
    *,
    name: str,
    material_slots=None,
    use_triangulate: bool = False,
    use_normals: bool = False,
    vertex_matrix=None,
    recorded_solid: bool | None = None,
    include_loose: bool = True,
) -> list[IRMeshGeometry]:
    """Split a Blender mesh into one IRMeshGeometry per used material slot, plus its loose edges (an IndexedLineSet)
    and, for a mesh of vertices only, a PointSet, unless ``include_loose`` is off.

    ``vertex_matrix`` (optional) transforms every vertex (used to express a
    skinned mesh in its armature's space).

    Vertices are split on (vertex, uv, color, normal) so that all X3D arrays
    share ``coordIndex``. Normals are only exported when ``use_normals`` is
    set; otherwise ``creaseAngle`` carries the smooth/flat intent.
    """

    polygons = getattr(mesh, "polygons", None)
    vertices = getattr(mesh, "vertices", None)
    loops = getattr(mesh, "loops", None)
    if not polygons or vertices is None or loops is None:
        if not include_loose:
            return _extract_edge_lines(mesh, name=name, vertex_matrix=vertex_matrix) if getattr(mesh, "edges", None) else []
        return _extract_loose_geometries(mesh, name=name, vertex_matrix=vertex_matrix, alone=True)
    geometries = _extract_face_geometries(mesh, name=name, material_slots=material_slots,
                                          use_triangulate=use_triangulate, use_normals=use_normals,
                                          vertex_matrix=vertex_matrix, recorded_solid=recorded_solid)
    if include_loose:
        geometries += _extract_loose_geometries(mesh, name=name, vertex_matrix=vertex_matrix, alone=not geometries)
    return geometries


def _extract_face_geometries(mesh, *, name, material_slots, use_triangulate, use_normals, vertex_matrix,
                             recorded_solid) -> list[IRMeshGeometry]:
    """The faces of ``mesh``, one IRMeshGeometry per used material slot (see extract_mesh_geometries)."""
    polygons, vertices, loops = mesh.polygons, mesh.vertices, mesh.loops

    uv_at = _uv_values(mesh)
    color_at, color_domain = _color_values(mesh)
    normal_at = _corner_normals(mesh) if use_normals else None

    tri_by_polygon: dict[int, list] = {}
    if use_triangulate:
        for tri in mesh.loop_triangles:
            tri_by_polygon.setdefault(tri.polygon_index, []).append(tri)

    def material_for_slot(slot_index):
        if not material_slots or slot_index >= len(material_slots):
            return None
        return getattr(material_slots[slot_index], "material", None)

    groups: dict[int, list] = {}
    for polygon in polygons:
        if len(polygon.vertices) < 3:
            continue
        groups.setdefault(int(polygon.material_index), []).append(polygon)

    geometries: list[IRMeshGeometry] = []
    multi = len(groups) > 1
    for slot_index in sorted(groups):
        group = groups[slot_index]
        vertex_map: dict[tuple, int] = {}
        coord: list[tuple[float, float, float]] = []
        normal: list[tuple[float, float, float]] = []
        tex_coord: list[tuple[float, float]] = []
        color: list[tuple[float, float, float, float]] = []
        coord_index: list[int] = []
        orig_index: list[int] = []
        any_smooth = False

        def emit_vertex(vertex_index, loop_index):
            key = [vertex_index]
            uv = uv_at(loop_index) if uv_at else None
            col = None
            if color_at:
                col = color_at(loop_index if color_domain == "CORNER" else vertex_index)
            nrm = normal_at(loop_index) if normal_at else None
            if uv is not None:
                key.append(tuple(round(value, _ROUND) for value in uv))
            if col is not None:
                key.append(tuple(round(value, _ROUND) for value in col))
            if nrm is not None:
                key.append(tuple(round(value, _ROUND) for value in nrm))
            key = tuple(key)
            index = vertex_map.get(key)
            if index is None:
                index = len(coord)
                vertex_map[key] = index
                position = vertices[vertex_index].co
                if vertex_matrix is not None:
                    position = vertex_matrix @ position
                coord.append(tuple(float(value) for value in position[:3]))
                orig_index.append(int(vertex_index))
                if uv is not None:
                    tex_coord.append((float(uv[0]), float(uv[1])))
                if col is not None:
                    color.append(col)
                if nrm is not None:
                    normal.append(tuple(float(value) for value in nrm))
            return index

        for polygon in group:
            if getattr(polygon, "use_smooth", False):
                any_smooth = True
            if use_triangulate:
                for tri in tri_by_polygon.get(polygon.index, ()):
                    for loop_index, vertex_index in zip(tri.loops, tri.vertices):
                        coord_index.append(emit_vertex(vertex_index, loop_index))
                    coord_index.append(-1)
            else:
                for loop_index in polygon.loop_indices:
                    coord_index.append(emit_vertex(loops[loop_index].vertex_index, loop_index))
                coord_index.append(-1)

        if not coord_index:
            continue

        material = material_for_slot(slot_index)
        solid = bool(getattr(material, "use_backface_culling", False)) if material else False
        solid = solid or bool(recorded_solid)
        crease_angle = None
        if normal_at is None:
            crease_angle = _crease_from_sharp_edges(mesh) if any_smooth else 0.0

        geometries.append(
            IRMeshGeometry(
                name=f"{name}_m{slot_index}" if multi else name,
                coord=coord,
                coord_index=coord_index,
                solid=solid,
                crease_angle=crease_angle,
                normal=normal,
                tex_coord=tex_coord,
                color=color,
                material_slot=slot_index,
                source_mesh=name,
                orig_vertex_index=orig_index,
            )
        )
    return geometries


# ---------------------------------------------------------------------------
# HAnim (armatures)


def _skinned_meshes(armature, candidates):
    """Mesh objects deformed by ``armature`` through an Armature modifier or armature parenting."""
    skinned = []
    for obj in candidates:
        if obj.type != "MESH":
            continue
        if any(m.type == "ARMATURE" and m.object == armature for m in obj.modifiers):
            skinned.append(obj)
        elif obj.parent == armature and obj.parent_type == "ARMATURE":
            skinned.append(obj)
    return skinned


def _build_joint_tree(armature, diagnostics=None):
    """Return (root IRJoints, {bone name: IRJoint}) from the armature's rest bones.

    Bones that follow a known naming convention (or carry ``x3d_hanim_joint``) get their H-Anim 2.0 joint name in
    ``hanim_name``.
    """
    joints = {}
    for bone in armature.data.bones:
        head = bone.head_local
        joints[bone.name] = IRJoint(name=bone.name, center=(float(head[0]), float(head[1]), float(head[2])))
    mapping, problems = map_bones(((bone.name, bone.get(HANIM_JOINT_PROPERTY)) for bone in armature.data.bones),
                                convention=str(armature.get(HANIM_NAMES_PROPERTY) or "").lower() == "standard")
    for bone_name, joint_name in mapping.items():
        joints[bone_name].hanim_name = joint_name
    if diagnostics is not None:
        diagnostics.extend(f"Armature {armature.name!r}: {problem}." for problem in problems)
    roots = []
    for bone in armature.data.bones:
        joint = joints[bone.name]
        if bone.parent is not None and bone.parent.name in joints:
            joints[bone.parent.name].children.append(joint)
        else:
            roots.append(joint)
    return roots, joints


def extract_humanoid(armature, skinned, *, local_matrix, material_sink, use_triangulate=False, diagnostics=None):
    """Build an HAnimHumanoid for ``armature`` with ``skinned`` meshes as skin.

    Skin vertices are expressed in armature space and pooled into one
    skinCoord list; each joint receives the vertex indices and weights of
    its vertex group. ``material_sink(material)`` registers a material and
    returns its name. Returns (humanoid, skin geometries).
    """
    roots, joints = _build_joint_tree(armature, diagnostics)
    skin_geometries: list[IRMeshGeometry] = []
    humanoid = IRHumanoid(name=armature.name, transform=_matrix_transform(local_matrix), root_joints=roots,
                          standard_joint_count=sum(1 for joint in joints.values() if joint.hanim_name))
    skin_def = f"hanim_{_safe_key(armature.name)}_skinCoord"
    armature_inverse = inverted64(armature.matrix_world, armature.name)

    for mesh_obj in skinned:
        mesh = mesh_obj.data
        if use_triangulate and hasattr(mesh, "calc_loop_triangles"):
            mesh.calc_loop_triangles()
        geometries = extract_mesh_geometries(
            mesh,
            name=f"{mesh_obj.name}_skin",
            material_slots=mesh_obj.material_slots,
            use_triangulate=use_triangulate,
            use_normals=False,
            vertex_matrix=armature_inverse @ mesh_obj.matrix_world,
            include_loose=False,   # a skin shares one skinCoord; a PointSet has no index into it
        )
        group_names = [group.name for group in mesh_obj.vertex_groups]
        for geometry in geometries:
            offset = len(humanoid.skin_coord)
            humanoid.skin_coord.extend(geometry.coord)
            for split_index, vertex_index in enumerate(geometry.orig_vertex_index):
                for element in mesh.vertices[vertex_index].groups:
                    if element.weight <= 0.0 or element.group >= len(group_names):
                        continue
                    joint = joints.get(group_names[element.group])
                    if joint is None:
                        continue
                    joint.skin_coord_index.append(offset + split_index)
                    joint.skin_coord_weight.append(float(element.weight))
            geometry.coord_index = [index + offset if index >= 0 else -1 for index in geometry.coord_index]
            geometry.coord = []
            geometry.skin_coord_def = skin_def
            slots = mesh_obj.material_slots
            material = slots[geometry.material_slot].material if slots and geometry.material_slot < len(slots) else None
            humanoid.skin_shapes.append(
                IRShape(geometry_name=geometry.name, material_name=material_sink(material) if material else None)
            )
        skin_geometries.extend(geometries)
    return humanoid, skin_geometries


def _safe_key(name: str) -> str:
    return "".join(char if (char.isalnum() or char == "_") else "_" for char in name)


def _sample_joint_animation(scene, armatures, frames, keys):
    """Per-frame HAnim joint rotation/translation relative to rest, for every bone.

    For bone b with rest matrix L_b (armature space) and posed matrix P_b,
    D_b = P_b @ L_b^-1 maps rest-space skin to posed skin. The joint's own
    transform is J_b = D_parent^-1 @ D_b, which HAnim applies about the joint
    center c: J = T(t) T(c) R T(-c), so t = J.translation - (c - R c).
    """
    samples = {}
    for frame in frames:
        scene.frame_set(frame)
        for armature in armatures:
            pose = armature.pose
            deltas = {}
            for bone in armature.data.bones:
                pose_bone = pose.bones.get(bone.name)
                if pose_bone is None:
                    continue
                deltas[bone.name] = pose_bone.matrix @ bone.matrix_local.inverted()
            for bone in armature.data.bones:
                delta = deltas.get(bone.name)
                if delta is None:
                    continue
                parent_delta = deltas.get(bone.parent.name) if bone.parent is not None else None
                joint_matrix = (parent_delta.inverted() @ delta) if parent_delta is not None else delta
                rotation = joint_matrix.to_quaternion()
                center = bone.head_local
                translation = joint_matrix.to_translation() - (center - rotation @ center)
                axis, angle = rotation.to_axis_angle()
                if abs(angle) < 1e-9:
                    axis, angle = (0.0, 0.0, 1.0), 0.0
                key = f"{armature.name}:{bone.name}"
                samples.setdefault(key, []).append(
                    (
                        (float(axis[0]), float(axis[1]), float(axis[2]), float(angle)),
                        (float(translation[0]), float(translation[1]), float(translation[2])),
                    )
                )
    animations = []
    for key, values in samples.items():
        rotations = [value[0] for value in values]
        translations = [value[1] for value in values]
        rotating = any(abs(rotation[3]) > 1e-6 for rotation in rotations)
        moving = any(max(abs(component) for component in translation) > 1e-6 for translation in translations)
        if not (rotating or moving):
            continue
        animations.append(
            IRAnimation(
                target=key,
                target_kind="joint",
                keys=list(keys),
                translations=translations if moving else [],
                rotations=rotations if rotating else [],
            )
        )
    return animations


def static_world_matrix(obj):
    """An object's world matrix from its own transform channels and its parents', not from ``matrix_world``.

    ``matrix_world`` is only refreshed for objects in a view layer; a collection kept out of the scene as an asset
    library holds whatever was last evaluated (identity for one built by script), so its members are placed from
    ``matrix_basis`` and ``matrix_parent_inverse`` instead.
    """
    matrix = obj.matrix_basis.copy()
    parent = obj.parent
    if parent is None:
        return matrix
    return static_world_matrix(parent) @ obj.matrix_parent_inverse @ matrix


# Matrix.decompose() squares the axis lengths in float32: beyond about 1e19 (or below about 1e-19) the square overflows
# (or underflows), the scale comes out inf or 0 and the rotation is wrong. Outside this range decompose in float64.
_DECOMPOSE_FLOAT32_LIMIT = 1e15


def _decompose64(matrix):
    """``Matrix.decompose()`` computed in float64, with the same sign convention (a mirror negates all three scales).

    An axis of length 0 has no direction: it is rebuilt from the other two, so the rotation stays orthonormal."""
    import numpy as np
    from mathutils import Matrix, Quaternion, Vector

    values = np.array(matrix, dtype=np.float64)
    linear = values[:3, :3]
    scale = np.linalg.norm(linear, axis=0)
    translation = Vector(values[:3, 3].tolist())
    columns = [linear[:, i] / scale[i] if scale[i] > 0.0 else None for i in range(3)]
    for i in range(3):
        if columns[i] is None:
            a, b = columns[(i + 1) % 3], columns[(i + 2) % 3]
            if a is None or b is None:  # two axes of length 0: no rotation can be recovered
                return translation, Quaternion(), Vector(scale.tolist())
            columns[i] = np.cross(a, b)
            columns[i] /= np.linalg.norm(columns[i])
    rotation = np.stack(columns, axis=1)
    if np.linalg.det(rotation) < 0.0:
        rotation, scale = -rotation, -scale
    return translation, Matrix(rotation.tolist()).to_quaternion(), Vector(scale.tolist())


def _matrix_transform(matrix) -> IRTransform:
    if any(s > _DECOMPOSE_FLOAT32_LIMIT or 0.0 < s < 1.0 / _DECOMPOSE_FLOAT32_LIMIT for s in axis_scales(matrix)):
        loc, rot, scale = _decompose64(matrix)
    else:
        loc, rot, scale = matrix.decompose()
    axis, angle = rot.to_axis_angle()
    if abs(angle) < 1e-9:
        axis = (0.0, 0.0, 1.0)
        angle = 0.0
    return IRTransform(
        translation=tuple(float(value) for value in loc[:3]),
        rotation_axis_angle=(float(axis[0]), float(axis[1]), float(axis[2]), float(angle)),
        scale=tuple(float(value) for value in scale[:3]),
    )


def is_lod_hidden(obj):
    """An object of an LOD level the importer hid (and the user has not unhidden): written as geometry it would be
    drawn on top of the level that is shown, so neither writer exports it."""
    return obj.get(LOD_HIDDEN_PROPERTY) is not None and bool(obj.hide_render)


def _iter_export_objects(scene, view_layer, *, use_selection, use_visible, use_active_collection):
    if use_active_collection and view_layer is not None:
        objects = view_layer.active_layer_collection.collection.all_objects
    else:
        objects = scene.objects
    for obj in objects:
        if use_selection and not obj.select_get():
            continue
        if use_visible and not obj.visible_get():
            continue
        if is_lod_hidden(obj):
            # the 4.0 writer has no LOD node; unhide the level (hide_render off) to export it
            continue
        yield obj


def _direction_neg_z(matrix):
    vector = matrix.to_3x3() @ type(matrix.to_translation())((0.0, 0.0, -1.0))
    vector.normalize()
    return (float(vector[0]), float(vector[1]), float(vector[2]))


def scene_head_meta(scene) -> list[tuple[str, str]]:
    """The (name, content) pairs of the head meta the importer kept on ``scene``, in file order."""
    entries = []
    for item in imported_scene_property(scene, HEAD_META_PROPERTY) or ():
        get = getattr(item, "get", None)
        if get is None:
            continue
        name, content = get("name"), get("content")
        if isinstance(name, str) and name and isinstance(content, str):
            entries.append((name, content))
    return entries


def object_metadata(item, depth: int = 0) -> IRMetadataNode | None:
    """The Metadata* node stored in an ``x3d_metadata`` custom property, or None when it is missing or malformed.

    ``value`` is the X3D text of the field (for MetadataSet, the list of member nodes); it is written as stored.
    """
    get = getattr(item, "get", None)
    if get is None or depth > 64 or get("node") not in METADATA_NODE_TYPES:
        return None
    node = IRMetadataNode(node_type=get("node"))
    for attribute in ("name", "reference"):
        text = get(attribute)
        if isinstance(text, str):
            setattr(node, attribute, text)
    value = get("value")
    if node.node_type == "MetadataSet":
        if value is not None and not isinstance(value, str):
            members = (object_metadata(member, depth + 1) for member in value)
            node.members = [member for member in members if member is not None]
    elif isinstance(value, str):
        node.value = value
    return node


def scene_background(scene) -> IRBackground | None:
    """The Background the importer kept on ``scene``, or None when there is none (or it has no sky colour)."""
    stored = imported_scene_property(scene, BACKGROUND_PROPERTY)
    get = getattr(stored, "get", None)
    if get is None:
        return None

    def numbers(key):
        values = get(key)
        if values is None or isinstance(values, str):
            return []
        try:
            return [float(value) for value in values]
        except (TypeError, ValueError):
            return []

    def colors(key):
        flat = numbers(key)
        return [tuple(flat[index:index + 3]) for index in range(0, len(flat) - 2, 3)]

    sky_color = colors("skyColor")
    if not sky_color:
        return None
    transparency = get("transparency")
    return IRBackground(
        sky_color=sky_color,
        sky_angle=numbers("skyAngle"),
        ground_color=colors("groundColor"),
        ground_angle=numbers("groundAngle"),
        transparency=float(transparency) if isinstance(transparency, (int, float)) else 0.0,
    )


def _unit_interval(value, default):
    """A custom-property number clamped to [0, 1], or ``default`` when it is unset or not a number."""
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def light_energy_per_intensity(data) -> float:
    """Blender energy per unit of X3D intensity: what an X_ITE-units import recorded on the light, else the
    legacy scale (point and spot 1.75 W, sun 1). Both exporters divide by it, so an imported light's intensity
    comes back as it was in the file whichever light units the import used."""
    factor = data.get(LIGHT_ENERGY_PER_INTENSITY_PROPERTY)
    try:
        factor = float(factor)
    except (TypeError, ValueError):
        factor = 0.0
    if factor > 0.0:
        return factor
    return 1.0 if data.type == "SUN" else 1.75


def light_intensity(data) -> float:
    """The X3D intensity to write for a light: its Blender energy over light_energy_per_intensity, except for a point
    or spot light the import found with ``radius`` 0. X_ITE lights nothing with such a light, so the import gives it
    energy 0; its intensity is then the file's (LIGHT_INTENSITY_PROPERTY), so the export writes the same light back.
    Once the light is given energy in Blender, the energy counts again."""
    energy = max(0.0, float(data.energy))
    if energy == 0.0 and data.type in ("POINT", "SPOT") and data.get(LIGHT_INTENSITY_PROPERTY) is not None:
        try:
            radius = float(data.get(LIGHT_RADIUS_PROPERTY))
        except (TypeError, ValueError):
            radius = None
        if radius == 0.0:
            return max(0.0, float(data[LIGHT_INTENSITY_PROPERTY]))
    return energy / light_energy_per_intensity(data)


def light_attenuation(data):
    """The X3D attenuation an import kept on a point or spot light, as three floats, else None."""
    value = data.get(LIGHT_ATTENUATION_PROPERTY)
    try:
        value = tuple(float(v) for v in value)
    except (TypeError, ValueError):
        return None
    return value if len(value) == 3 else None


def light_radius(data):
    """The X3D radius to write for a point or spot light: the file's (kept by the import), else Blender's cutoff
    distance when it is set, else X3D's default 100. None for a light made in Blender, whose spot radius the legacy
    mapping derives from the cone."""
    value = data.get(LIGHT_RADIUS_PROPERTY)
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def imported_spot_cone(data):
    """(beamWidth, cutOffAngle) of a spot light imported from X3D: the inverse of the import's mapping
    (spot_size = 2 cutOffAngle, inner cone = beamWidth), so the file's cone comes back. A hard-edged cone
    (beamWidth >= cutOffAngle in the file) comes back with beamWidth = cutOffAngle, which X3D draws the same."""
    cut_off = float(data.spot_size) / 2.0
    return cut_off * (1.0 - float(data.spot_blend)), cut_off


def light_colour(data, colour_space):
    """A light's X3D color next to classic Materials (the X3D 3.3 writer), written like their colours
    (display_colour): under 'SRGB' the file's value (LIGHT_COLOR_PROPERTY) while the Blender colour is still what the
    import made of it, else the Blender colour sRGB-encoded, the way X_ITE 16.7.1 lights a classic Material (its
    X3DMaterialNode picks X3D_COLORSPACE_SRGB when isPhysical () is false, dist/x_ite.js line 71561, and the colour
    maths runs on the color field as given); under 'AS_IS' the Blender colour unchanged. Clamped to [0, 1]."""
    colour = tuple(max(0.0, min(1.0, float(channel))) for channel in data.color[:3])
    if colour_space != 'SRGB':
        return colour
    stored = data.get(LIGHT_COLOR_PROPERTY)
    if stored is not None:
        stored = tuple(float(channel) for channel in stored)[:3]
        if all(abs(srgb_to_linear(a) - b) < 1e-5 for a, b in zip(stored, colour)):
            return stored
    return display_colour(colour, colour_space)


def physical_light_colour(data):
    """A light's X3D color next to PhysicalMaterials (the X3D 4.0/4.1 writer): the Blender colour, linear, clamped to
    [0, 1]. X_ITE 16.7.1 lights a PhysicalMaterial in linear space: X3DLightNode.getColor () hands the color field to
    the shader unchanged (dist/x_ite.js lines 63900 and 82640), Punctual2.glsl's getLightIntensity returns
    intensity * light.color (line 67903 on), PBR2.glsl multiplies that by the linear baseColor (l_diffuse, line 67826)
    and ToneMapping2.glsl encodes the sum to sRGB at the end under X3D_COLORSPACE_LINEAR (line 67952), the colour space
    X3DMaterialNode picks for a PhysicalMaterial (line 71561, isPhysical () line 87646). The importer keeps a physical
    scene's light colours as given, so the colour comes back unchanged."""
    return tuple(max(0.0, min(1.0, float(channel))) for channel in data.color[:3])


def srgb_to_linear(value):
    """One sRGB-encoded channel as linear (the inverse of linear_to_srgb)."""
    value = float(value)
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4


def _extract_light(obj, local_matrix, material_model='physical', colour_space='AS_IS') -> IRLight:
    """Mirror the legacy exporter's light mapping; values are local to the object's Transform.

    A light imported from X3D (it carries ``x3d_intensity``) is written without capping intensity at 1: the
    X3D 4.0 schema gives light intensity no upper limit, and its energy maps back to the value in the file. A
    light made in Blender keeps the [0, 1] cap: watts have no fixed X3D scale and this writer emits no
    attenuation, so a 1000 W point light (energy / 1.75 = 571) would white out the scene in a browser. The
    legacy X3D 3.x writer caps every light because the 3.x schemas limit intensity to [0, 1].
    ``shadows`` follows the light's shadow switch; ambientIntensity and shadowIntensity have no Blender
    setting and come from the custom properties the importer leaves on the light data.
    """
    data = obj.data
    light_type = {"POINT": "POINT", "SPOT": "SPOT", "SUN": "DIRECTIONAL"}.get(data.type, "DIRECTIONAL")
    intensity = light_intensity(data)
    if data.get(LIGHT_INTENSITY_PROPERTY) is None:
        intensity = min(intensity, 1.0)
    light = IRLight(
        name=obj.name,
        light_type=light_type,
        # the light's colour is read the way the Materials it lights are: sRGB values next to Materials (classic), linear
        # next to PhysicalMaterials (see light_colour and physical_light_colour)
        color=light_colour(data, colour_space) if material_model == 'classic' else physical_light_colour(data),
        intensity=intensity,
        ambient_intensity=_unit_interval(data.get(LIGHT_AMBIENT_INTENSITY_PROPERTY), 0.0),
        scoped=data.get(LIGHT_GLOBAL_PROPERTY) is not None and not data.get(LIGHT_GLOBAL_PROPERTY)
        and not data.get(LIGHT_SCOPE_LIT_PROPERTY, True),
        location=tuple(float(value) for value in local_matrix.to_translation()[:3]),
        direction=_direction_neg_z(local_matrix),
        shadows=bool(getattr(data, "use_shadow", False)),
        shadow_intensity=_unit_interval(data.get(LIGHT_SHADOW_INTENSITY_PROPERTY), None),
    )
    if light_type != "DIRECTIONAL":
        light.attenuation = light_attenuation(data)
    cutoff = float(getattr(data, "cutoff_distance", 0.0) or 0.0)
    radius = light_radius(data)
    if light_type == "POINT":
        light.radius = radius if radius is not None else (cutoff if cutoff > 0.0 else 100.0)
    elif light_type == "SPOT":
        if data.get(LIGHT_INTENSITY_PROPERTY) is not None:   # imported: the file's cone and radius
            light.beam_width, light.cut_off_angle = imported_spot_cone(data)
        else:
            light.beam_width = float(data.spot_size) * 0.37
            light.cut_off_angle = min(light.beam_width * 1.3, math.pi / 2.0)
        light.radius = radius if radius is not None else \
            ((cutoff * math.cos(light.beam_width)) if cutoff > 0.0 else 100.0)
    return light


def _world_color(world):
    """What the render shows behind the scene: the node-tree Background colour x strength when the world uses
    nodes and nothing is linked into it, else the viewport ``World.color``."""
    tree = getattr(world, "node_tree", None)
    if tree is not None and getattr(world, "use_nodes", True):
        for node in tree.nodes:
            if node.type != "BACKGROUND":
                continue
            color, strength = node.inputs.get("Color"), node.inputs.get("Strength")
            if color is None or color.is_linked or (strength is not None and strength.is_linked):
                break
            k = float(strength.default_value) if strength is not None else 1.0
            return tuple(float(c) * k for c in color.default_value[:3])
    return tuple(world.color[:3])


# Blender's default camera clip range, which the export leaves out (a Viewpoint without nearDistance and farDistance).
DEFAULT_CLIP_START = 0.1
DEFAULT_CLIP_END = 1000.0


def _clip_distances(data, distance_scale=1.0):
    """(nearDistance, farDistance) of a camera for the X3D 4.0 Viewpoint, each None while it is Blender's default.

    X_ITE 16.7.1 without a farDistance draws out to 1e5 (1e10 with a logarithmic depth buffer) at most from a
    navigation near distance of 0.125: a GeoViewpoint 2.5e7 m above a 6.4e6 m globe imported with its clip range
    (import_x3d.importGeoViewpoint_Matrix) came back from the export with none, and X_ITE drew a black frame."""
    near = far = None
    try:
        start, end = float(data.clip_start) * distance_scale, float(data.clip_end) * distance_scale
    except (AttributeError, TypeError, ValueError):
        return None, None
    if not math.isclose(start, DEFAULT_CLIP_START * distance_scale, rel_tol=1e-4) and start > 0.0:
        near = start
    if not math.isclose(end, DEFAULT_CLIP_END * distance_scale, rel_tol=1e-4) and end > 0.0:
        far = end
    if near is not None and far is not None and far <= near:
        return None, None
    return near, far


def _extract_viewpoint(obj, local_matrix, scene=None, distance_scale=1.0) -> IRViewpoint:
    """The description is the one the importer kept, or the camera's name when there is none."""
    field_of_view = None
    if obj.data.type == "PERSP":
        field_of_view = float(obj.data.angle)
        if scene is not None:
            # X3D measures fieldOfView across the smaller side of the view, Blender across the fitted side.
            field_of_view = x3d_field_of_view(field_of_view, obj.data.sensor_fit, *render_size(scene))
    description = obj.get(VIEWPOINT_DESCRIPTION_PROPERTY)
    near, far = _clip_distances(obj.data, distance_scale)
    return IRViewpoint(
        name=obj.name,
        description=description if isinstance(description, str) and description else obj.name,
        transform=_matrix_transform(local_matrix),
        field_of_view=field_of_view,
        near_distance=near,
        far_distance=far,
    )


def _sample_animation(scene, objects_by_name, *, use_hierarchy, global_matrix, frame_step=1, armatures=()):
    """Sample every exported object's local transform per frame.

    Returns (animations, cycle_interval). Objects whose transform never changes
    produce no animation.
    """
    frame_start, frame_end = scene.frame_start, scene.frame_end
    if frame_end <= frame_start:
        return [], None
    fps = scene.render.fps / scene.render.fps_base
    current = scene.frame_current
    frames = list(range(frame_start, frame_end + 1, max(1, int(frame_step))))
    if frames[-1] != frame_end:
        frames.append(frame_end)
    samples: dict[str, list] = {name: [] for name in objects_by_name}
    try:
        for frame in frames:
            scene.frame_set(frame)
            for name, (obj, parent) in objects_by_name.items():
                matrix = obj.matrix_world
                if use_hierarchy and parent is not None:
                    matrix = inverted64(parent.matrix_world, parent.name) @ matrix
                elif global_matrix is not None:
                    matrix = global_matrix @ matrix
                samples[name].append(_matrix_transform(matrix))
        span = float(frame_end - frame_start)
        keys = [(frame - frame_start) / span for frame in frames]
        joint_animations = _sample_joint_animation(scene, list(armatures), frames, keys) if armatures else []
    finally:
        scene.frame_set(current)

    animations = list(joint_animations)
    for name, transforms in samples.items():
        first = transforms[0]
        moving = any(t.translation != first.translation for t in transforms)
        rotating = any(t.rotation_axis_angle != first.rotation_axis_angle for t in transforms)
        scaling = any(t.scale != first.scale for t in transforms)
        if not (moving or rotating or scaling):
            continue
        animations.append(
            IRAnimation(
                target=name,
                keys=keys,
                translations=[t.translation for t in transforms] if moving else [],
                rotations=[t.rotation_axis_angle for t in transforms] if rotating else [],
                scales=[t.scale for t in transforms] if scaling else [],
            )
        )
    return animations, span / fps


def _action_fcurves(action):
    """The F-curves of an action: ``fcurves`` before Blender 5, the first layered-action channel bag after."""
    fcurves = getattr(action, "fcurves", None)
    if fcurves is not None and len(fcurves):
        return fcurves
    try:
        return action.layers[0].strips[0].channelbag(action.slots[0]).fcurves
    except Exception:
        return fcurves if fcurves is not None else []


def _sample_shape_key_morphs(scene, depsgraph, sources, geometries_by_key, *, frame_step=1):
    """Sample the shape-key animation of each mesh into ``morph_keys`` / ``morph_states`` on its geometries.

    ``sources`` maps a geometry key to the mesh object that owns it. Samples sit at the shape-key keyframes
    (the interpolator is linear between them, so those are exact for LINEAR keyframes); when any keyframe
    uses another interpolation every ``frame_step`` frame is sampled too. A mesh whose evaluated vertex count
    differs from its data (a modifier changed the topology) is skipped. Returns the cycle interval in seconds
    when a morph was written, else None.
    """
    import bpy

    frame_start, frame_end = scene.frame_start, scene.frame_end
    if frame_end <= frame_start or not sources:
        return None
    fps = scene.render.fps / scene.render.fps_base
    span = float(frame_end - frame_start)
    current_frame, current_sub = scene.frame_current, scene.frame_subframe
    written = False
    try:
        for geometry_key, obj in sources.items():
            key = obj.data.shape_keys
            action = key.animation_data.action if key is not None and key.animation_data else None
            if action is None:
                continue
            frames = {float(frame_start), float(frame_end)}
            linear = True
            for fcurve in _action_fcurves(action):
                if not fcurve.data_path.endswith(".value"):
                    continue
                for point in fcurve.keyframe_points:
                    frame = float(point.co[0])
                    if frame_start <= frame <= frame_end:
                        frames.add(frame)
                    linear = linear and point.interpolation == "LINEAR"
            if not linear:
                frames.update(float(f) for f in range(frame_start, frame_end + 1, max(1, int(frame_step))))
            frames = sorted(frames)
            vertex_count = len(obj.data.vertices)
            samples = []
            for frame in frames:
                whole = math.floor(frame)
                scene.frame_set(whole, subframe=frame - whole)
                evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                mesh = evaluated.to_mesh()
                try:
                    if len(mesh.vertices) != vertex_count:
                        samples = None
                        break
                    samples.append([tuple(float(c) for c in v.co[:3]) for v in mesh.vertices])
                finally:
                    evaluated.to_mesh_clear()
            if not samples or all(state == samples[0] for state in samples):
                continue
            keys = [(frame - frame_start) / span for frame in frames]
            for geometry in geometries_by_key.get(geometry_key, []):
                if geometry.is_lines or geometry.is_points or geometry.skin_coord_def or not geometry.orig_vertex_index:
                    continue
                geometry.morph_keys = keys
                geometry.morph_states = [[state[i] for i in geometry.orig_vertex_index] for state in samples]
                written = True
    finally:
        scene.frame_set(current_frame, subframe=current_sub)
    return span / fps if written else None


def extract_scene(
    scene,
    *,
    view_layer=None,
    depsgraph=None,
    global_matrix=None,
    use_selection: bool = True,
    use_active_collection: bool = False,
    use_visible: bool = False,
    use_hierarchy: bool = True,
    use_mesh_modifiers: bool = False,
    use_triangulate: bool = False,
    use_normals: bool = False,
    use_animation: bool = False,
    animation_step: int = 1,
    metadata: dict | None = None,
    material_model: str | None = None,
    colour_space: str = 'AS_IS',
) -> IRScene:
    """Build the scene IR used by the X3D 4.0 emitter.

    With ``use_hierarchy`` every exported object becomes a Transform whose
    matrix is relative to its exported parent; otherwise objects are written
    flat with world matrices. Meshes, curves, surfaces and text become
    IndexedFaceSets; lights and cameras become X3D lights and Viewpoints.
    """

    metadata = metadata or {}
    meta = IRMetadata(
        creator=metadata.get("creator"),
        title=metadata.get("title"),
        description=metadata.get("description"),
        keywords=metadata.get("keywords"),
        reference=metadata.get("reference"),
        license=metadata.get("license"),
        filename=metadata.get("filename"),
        entries=scene_head_meta(scene),
    )

    ir_scene = IRScene(name=scene.name, metadata=meta)
    ir_scene.material_model = resolve_material_model(material_model, scene)
    ir_scene.material_model_forced = str(material_model or "").strip().lower() in MATERIAL_MODELS
    ir_scene.headlight = scene_headlight(scene)
    # An imported Background keeps its gradient; otherwise the world's colour becomes a plain one.
    ir_scene.background = scene_background(scene)
    world = getattr(scene, "world", None)
    if ir_scene.background is None and world is not None and getattr(world, "color", None) is not None:
        ir_scene.background_color = tuple(max(0.0, min(1.0, float(channel))) for channel in _world_color(world)[:3])

    exported = list(
        _iter_export_objects(
            scene,
            view_layer,
            use_selection=use_selection,
            use_visible=use_visible,
            use_active_collection=use_active_collection,
        )
    )
    exported_names = {obj.name for obj in exported}
    # Objects imported from an Inline are represented by their placeholder empty's Inline node.
    inline_children = [obj for obj in exported if (root := inline_root(obj)) is not None and root.name in exported_names]
    if inline_children:
        exported = [obj for obj in exported if obj not in inline_children]
        exported_names = {obj.name for obj in exported}
        ir_scene.diagnostics.append(
            f"{len(inline_children)} object(s) imported from Inline assets are referenced by Inline rather than re-exported."
        )

    def exported_parent(obj):
        parent = obj.parent
        while parent is not None and parent.name not in exported_names:
            parent = parent.parent
        return parent

    source_keys: dict[str, str] = {}
    material_names: set[str] = set()
    geometries_by_key: dict[str, list[IRMeshGeometry]] = {}
    morph_sources: dict[str, object] = {}
    skipped_types: dict[str, int] = {}
    objects_by_name: dict[str, tuple] = {}
    armatures = [obj for obj in exported if obj.type == "ARMATURE"]
    skinned_by_armature = {armature.name: _skinned_meshes(armature, exported) for armature in armatures}
    skinned_names = {mesh.name for meshes in skinned_by_armature.values() for mesh in meshes}

    def register_material(material):
        if material is None:
            return None
        if material.name not in material_names:
            analyzed = analyze_material(material)
            if analyzed:
                ir_scene.materials.append(analyzed)
                material_names.add(material.name)
        return material.name

    def mesh_shapes(obj):
        """Return the IRShape list for a mesh-like object, extracting geometry on first sight."""
        # A mesh whose only "modifier" is an animated shape key is written as its Basis plus a CoordinateInterpolator
        # (see _sample_shape_key_morphs) instead of the pose at the current frame.
        key_animation = getattr(getattr(obj.data, "shape_keys", None), "animation_data", None) if obj.type == "MESH" else None
        shape_key_morph = bool(use_animation and key_animation is not None and key_animation.action is not None and not obj.modifiers)
        needs_eval = obj.type != "MESH" or bool(
            use_mesh_modifiers and depsgraph is not None and not shape_key_morph and obj.is_modified(scene, "PREVIEW")
        )
        geometry_key = obj.name if needs_eval else obj.data.name
        source_key = f"{obj.type}:{geometry_key}"
        source_keys.setdefault(source_key, obj.name)

        primitive = primitive_for_mesh(obj.data) if obj.type == "MESH" and not needs_eval else None
        if primitive is not None:
            slots = obj.material_slots
            material = next((slot.material for slot in slots if slot.material is not None), None) if slots else None
            if material and material.name not in material_names:
                analyzed = analyze_material(material)
                if analyzed:
                    ir_scene.materials.append(analyzed)
                    material_names.add(material.name)
            # the file's own solid (kept with the primitive) or, as before, the material's culling
            primitive["fields"]["solid"] = bool(primitive["fields"].get("solid", False)) or (
                bool(getattr(material, "use_backface_culling", False)) if material else False)
            primitive["mesh"] = obj.data.name
            return source_key, [IRShape(material_name=material.name if material else None,
                                        geometry_hint=primitive["node"], primitive=primitive)]

        geometries = geometries_by_key.get(geometry_key)
        if shape_key_morph and not needs_eval:
            morph_sources.setdefault(geometry_key, obj)
        if geometries is None:
            mesh = None
            owner = obj
            try:
                if needs_eval:
                    owner = obj.evaluated_get(depsgraph) if depsgraph is not None else obj
                    try:
                        mesh = owner.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
                    except TypeError:
                        mesh = owner.to_mesh()
                else:
                    mesh = obj.data
                if mesh is not None:
                    if use_triangulate and hasattr(mesh, "calc_loop_triangles"):
                        mesh.calc_loop_triangles()
                    geometries = extract_mesh_geometries(
                        mesh,
                        name=geometry_key,
                        material_slots=obj.material_slots,
                        use_triangulate=use_triangulate,
                        use_normals=use_normals,
                        recorded_solid=obj.data.get(SOLID_PROPERTY) if obj.type == "MESH" else None,
                    )
                else:
                    geometries = []
            finally:
                if needs_eval and mesh is not None:
                    owner.to_mesh_clear()
            geometries_by_key[geometry_key] = geometries
            ir_scene.geometries.extend(geometries)

        shapes: list[IRShape] = []
        slots = obj.material_slots
        for geometry in geometries:
            material = None
            if slots and geometry.material_slot < len(slots):
                material = slots[geometry.material_slot].material
            material_name = material.name if material else None
            if material and material.name not in material_names:
                analyzed = analyze_material(material)
                if analyzed:
                    ir_scene.materials.append(analyzed)
                    material_names.add(material.name)
            shapes.append(IRShape(geometry_name=geometry.name, material_name=material_name))
        return source_key, shapes

    content_frame = asset_frame(global_matrix)
    glb_objects: set[str] = set()
    try:
        distance_scale = float(global_matrix.median_scale) if global_matrix is not None else 1.0
    except (AttributeError, TypeError, ValueError):
        distance_scale = 1.0

    def collection_instance(collection):
        """Extract a collection's mesh-like objects once, in the collection's frame; return its name."""
        from mathutils import Matrix
        name = collection.name
        if name in ir_scene.collections:
            return name
        ir_scene.collections[name] = members = []        # registered first: a collection that instances itself ends
        offset = Matrix.Translation(-collection.instance_offset)
        for member in collection.all_objects:
            if member.type not in MESH_LIKE_TYPES or member.name in skinned_names or is_lod_hidden(member):
                continue
            built = build_instance(member, None, local_override=offset @ static_world_matrix(member),
                                   name_prefix=f"{name}.")
            if built is not None:
                members.append(built)
        return name

    instance_shapes: dict[str, list[IRShape]] = {}

    def geometry_instances(obj, name_prefix):
        """Child instances for what ``obj``'s modifiers instance (Geometry Nodes Instance on Points, ...).

        The evaluated mesh of such an object has no faces: the instances are separate entries of the depsgraph,
        each an evaluated object valid only while the iteration is on it, so its geometry is extracted there. Each
        distinct instanced mesh is written once (keyed by its data) and USE'd by the other instances."""
        from types import SimpleNamespace
        world_inverse = inverted64(obj.matrix_world, obj.name)
        keys: dict[int, str] = {}
        children: list[IRInstance] = []
        skipped = 0
        for item in depsgraph.object_instances:
            if not item.is_instance or item.parent is None or item.parent.original != obj:
                continue
            source = item.object
            if source.type != "MESH" or source.data is None:
                skipped += 1
                continue
            pointer = source.data.as_pointer()
            key = keys.get(pointer)
            if key is None:
                key = keys[pointer] = f"{name_prefix}{obj.name}.instance{len(keys)}"
                mesh = source.data
                slots = list(source.material_slots) or [SimpleNamespace(material=m) for m in mesh.materials]
                if use_triangulate and hasattr(mesh, "calc_loop_triangles"):
                    mesh.calc_loop_triangles()
                geometries = extract_mesh_geometries(mesh, name=key, material_slots=slots,
                                                     use_triangulate=use_triangulate, use_normals=use_normals)
                geometries_by_key[key] = geometries
                ir_scene.geometries.extend(geometries)
                shapes = []
                for geometry in geometries:
                    material = slots[geometry.material_slot].material if geometry.material_slot < len(slots) else None
                    shapes.append(IRShape(geometry_name=geometry.name, material_name=register_material(material)))
                instance_shapes[key] = shapes
            shapes = instance_shapes[key]
            child = IRInstance(
                source_key=f"INSTANCE:{key}",
                object_name=f"{name_prefix}{obj.name}.instance{len(children)}",
                object_type="MESH",
                transform=_matrix_transform(world_inverse @ item.matrix_world.copy()),
                shapes=list(shapes),
                cast_shadow=bool(getattr(obj, "visible_shadow", True)),
            )
            if shapes:
                child.geometry_name, child.material_name = shapes[0].geometry_name, shapes[0].material_name
            else:
                child.no_faces = True
            children.append(child)
        if skipped:
            ir_scene.diagnostics.append(f"Object {obj.name!r}: {skipped} instance(s) of non-mesh data were not written.")
        return children

    def build_instance(obj, parent, local_override=None, name_prefix=""):
        if local_override is not None:
            local_matrix = local_override
        elif use_hierarchy and parent is not None:
            local_matrix = inverted64(parent.matrix_world, parent.name) @ obj.matrix_world
            if parent.get(INLINE_URL_PROPERTY):
                # the parent's Transform includes the asset frame; take it back out
                local_matrix = content_frame.inverted() @ local_matrix
        else:
            local_matrix = (global_matrix @ obj.matrix_world) if global_matrix is not None else obj.matrix_world
        if obj.type == "EMPTY" and obj.get(INLINE_URL_PROPERTY):
            # the import may have moved an extreme scale onto the loaded content (matrix_safety); the Inline's
            # Transform gets it back, since that content is not written
            local_matrix = local_matrix @ scale_to_children_matrix(obj) @ content_frame

        instance = IRInstance(
            source_key=f"{obj.type}:{obj.name}",
            object_name=name_prefix + obj.name,
            object_type=obj.type,
            transform=_matrix_transform(local_matrix),
        )
        # only what the import hid for a Switch is written invisible; hide_render on any other object is a Blender-side
        # choice that does not reach the children, while visible="false" would hide the whole subtree
        instance.visible = not (bool(getattr(obj, "hide_render", False)) and obj.get(SWITCH_HIDDEN_PROPERTY) is not None)
        if not name_prefix:
            objects_by_name[obj.name] = (obj, parent if use_hierarchy else None)
            instance.interaction = read_interaction(obj, ir_scene.diagnostics)

        if obj.name in skinned_names:
            # Written as HAnim skin under its armature instead of a plain Shape.
            objects_by_name.pop(obj.name, None)
            return None

        if obj.type == "ARMATURE":
            humanoid, skin_geometries = extract_humanoid(
                obj,
                skinned_by_armature.get(obj.name, []),
                local_matrix=local_matrix,
                material_sink=register_material,
                use_triangulate=use_triangulate,
                diagnostics=ir_scene.diagnostics,
            )
            ir_scene.geometries.extend(skin_geometries)
            ir_scene.humanoids.append(humanoid)
            ir_scene.object_names.append(obj.name)
            objects_by_name.pop(obj.name, None)
            instance.humanoid_name = humanoid.name
        elif is_splat_mesh(obj) or is_native_splat_object(obj):
            splats_name = obj.data.name
            if splats_name not in {splats.name for splats in ir_scene.splats}:
                reader = extract_native_splats if obj.type == "POINTCLOUD" else extract_splats
                new_splats = reader(obj.data, name=splats_name)
                if obj.get(SPLAT_GLB_PROPERTY) or obj.data.get(SPLAT_GLB_PROPERTY):
                    # written as a KHR_gaussian_splatting glb beside the file and referenced by Inline: the Inline's
                    # Transform carries the asset frame, like an imported Inline's does
                    if splats_to_gltf_frame(new_splats, global_matrix):
                        ir_scene.diagnostics.append(
                            f"Splats {splats_name!r}: spherical harmonics above degree 0 are not written to the glb "
                            "(view-dependent colour is lost; the X3D 4.1 GaussianSplats node keeps it).")
                    new_splats.glb_name = f"{_safe_key(splats_name)}.splats.glb"
                    glb_objects.add(splats_name)
                ir_scene.splats.append(new_splats)
            if splats_name in glb_objects:
                instance.transform = _matrix_transform(local_matrix @ content_frame)
            instance.source_key = f"SPLATS:{splats_name}"
            instance.splats_name = splats_name
            ir_scene.object_names.append(obj.name)
        elif obj.type in MESH_LIKE_TYPES:
            source_key, shapes = mesh_shapes(obj)
            instance.source_key = source_key
            instance.shapes = shapes
            instance.cast_shadow = bool(getattr(obj, "visible_shadow", True))
            instance.metadata = object_metadata(obj.get(METADATA_PROPERTY))
            instance.line_width = _line_width(obj)
            # Geometry Nodes (and particle) instances; vertex/face instancing instances child objects, which are
            # written as objects of their own
            # (only for meshes: a curve, surface or text object's own evaluated mesh is listed as an instance of it, and
            # that mesh is already written above)
            if (use_mesh_modifiers and depsgraph is not None and obj.type == "MESH"
                    and getattr(obj, "instance_type", "NONE") not in {"VERTS", "FACES"}):
                instance.children.extend(geometry_instances(obj, name_prefix))
            if shapes:
                instance.geometry_name = shapes[0].geometry_name
                instance.material_name = shapes[0].material_name
            else:
                instance.no_faces = True
                if not instance.children:
                    ir_scene.diagnostics.append(f"Object {obj.name!r} has no exportable faces.")
            ir_scene.object_names.append(obj.name)
        elif obj.type == "LIGHT":
            # Light values are local to the object's Transform, which carries the matrix.
            instance.light = _extract_light(obj, local_matrix.__class__(), ir_scene.material_model, colour_space)
            if instance.light.scoped:
                ir_scene.diagnostics.append(
                    f"Light {obj.name!r} was not global and lit nothing in the imported file; it is written with "
                    'global="false" again, so it still lights nothing.')
            elif obj.data.get(LIGHT_GLOBAL_PROPERTY) is not None and not obj.data.get(LIGHT_GLOBAL_PROPERTY):
                ir_scene.diagnostics.append(
                    f"Light {obj.name!r} was scoped to its group in the imported file (global=false); it is written "
                    'with global="true" because a Blender light lights the whole scene, so it now lights geometry '
                    "outside that scope too.")
            ir_scene.object_names.append(obj.name)
        elif obj.type == "CAMERA":
            instance.viewpoint = _extract_viewpoint(obj, local_matrix.__class__(), scene, distance_scale)
            ir_scene.object_names.append(obj.name)
        elif obj.type == "EMPTY" and getattr(obj, "instance_type", "NONE") == "COLLECTION" and obj.instance_collection is not None:
            instance.collection_name = collection_instance(obj.instance_collection)
            ir_scene.object_names.append(obj.name)
        elif obj.type == "EMPTY":
            inline_url = obj.get(INLINE_URL_PROPERTY)
            if inline_url:
                instance.inline = IRInlineAsset(url=str(inline_url), source_path=inline_source_path(_session_uid(obj), str(inline_url)))
            ir_scene.object_names.append(obj.name)
        else:
            skipped_types[obj.type] = skipped_types.get(obj.type, 0) + 1
            if not use_hierarchy:
                return None

        if use_hierarchy:
            for child in exported:
                if exported_parent(child) is obj:
                    child_instance = build_instance(child, obj)
                    if child_instance is not None:
                        instance.children.append(child_instance)
        return instance

    if use_hierarchy:
        roots = [obj for obj in exported if exported_parent(obj) is None]
        for obj in roots:
            instance = build_instance(obj, None)
            if instance is not None:
                ir_scene.instances.append(instance)
    else:
        for obj in exported:
            instance = build_instance(obj, None)
            if instance is not None:
                ir_scene.instances.append(instance)

    if use_animation and (objects_by_name or armatures):
        ir_scene.animations, ir_scene.cycle_interval = _sample_animation(
            scene,
            objects_by_name,
            use_hierarchy=use_hierarchy,
            global_matrix=global_matrix,
            frame_step=animation_step,
            armatures=armatures,
        )

    # The viewpoint tour: cameras that carry x3d_tour_order, as Viewpoint poses in the exported frame.
    def tour_transform(camera):
        matrix = (global_matrix @ camera.matrix_world) if global_matrix is not None else camera.matrix_world
        return _matrix_transform(matrix.normalized())

    cameras = [obj for obj in exported if obj.type == "CAMERA"]
    ir_scene.tour = read_tour(cameras, scene, tour_transform)
    if ir_scene.tour is not None:
        fields = {camera.name: _extract_viewpoint(camera, camera.matrix_world.__class__(), scene, distance_scale).field_of_view
                  for camera in cameras}
        for stop in ir_scene.tour.stops:
            stop.field_of_view = fields.get(stop.name)
    check_interactions(ir_scene, ir_scene.diagnostics)

    if use_animation and morph_sources:
        morph_cycle = _sample_shape_key_morphs(scene, depsgraph, morph_sources, geometries_by_key, frame_step=animation_step)
        if morph_cycle is not None and ir_scene.cycle_interval is None:
            ir_scene.cycle_interval = morph_cycle

    for object_type, count in sorted(skipped_types.items()):
        ir_scene.diagnostics.append(
            f"Skipped {count} {object_type} object(s): not yet supported by the X3D 4.0 path."
        )

    if not ir_scene.object_names:
        ir_scene.diagnostics.append("No exportable objects matched the current filters.")
    else:
        instances = list(ir_scene.iter_instances())
        shared_sources = {
            source_key: owner_name
            for source_key, owner_name in source_keys.items()
            if sum(1 for instance in instances if instance.source_key == source_key) > 1
        }
        if shared_sources:
            ir_scene.diagnostics.append(
                "Reused geometry (DEF/USE): "
                + ", ".join(f"{source_key}->{owner_name}" for source_key, owner_name in sorted(shared_sources.items()))
            )

    return ir_scene
